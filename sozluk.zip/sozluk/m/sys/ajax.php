<?
session_start();
include "config.php";
include "../lib/class.sozluk.php";
include '../lib/class.phpmailer.php';
$sozluk = new sozluk;
// ajax process
if($_POST['process']=='login'){
	$email = $_POST['mail'];
	$password = md5($_POST['pass']);
	$count = DB::getVar('SELECT Count(id),ad FROM user WHERE mail = ? and pass = ? ',array($email,$password));
	if($count>0){
		$user = DB::getRow('SELECT * FROM user WHERE mail = "'.$email.'"');
		if($user->yetki=='silik'){
			echo 0;
		}else{
			$_SESSION['user']=$user->ad;
			$_SESSION['yetki']=$user->yetki;	
		}
		echo 1;
	}
	else echo 0;
}
else if($_POST['process']=='entry_liste'){
	$baslik = $_POST['baslik'];
	$entries = DB::get('SELECT * FROM entry WHERE baslik = ?',array($baslik));
	foreach ($entries as $entry) {
		$yazar = DB::getRow('SELECT * FROM user WHERE ad = ?',array($entry->yazar));
		echo '<div class="ui-block-solo entry_div"><div class="ui-block-solo">'.$sozluk->convert($entry->metin).'</div></div>
		<div class="ui-block-solo entry_alt">
		<span style="padding-bottom:4px;height:40px;float:left">
		<a id="'.$entry->id.'" class="entry_arti ui-btn ui-icon-plus ui-btn-icon-notext ui-corner-all" style="float:left;margin-left:5px"></a><a id="'.$entry->id.'"  style="float:left;margin-left:5px" class="entry_eksi ui-btn ui-icon-minus ui-btn-icon-notext ui-corner-all"></a><a style="margin-left:5px;float:left" id="'.$entry->id.'" class="entry_fav ui-btn ui-icon-heart ui-btn-icon-notext ui-corner-all"></a>
		</span>
		<img class="profil_resmi" id="'.$yazar->id.'" src="http://sozluksau.com/img/'.$yazar->img.'" style="height:40px;width:40px;float:right">
		<span style="margin-right:10px;padding-top:3px;height:40px;float:right;text-align:right;font-family:Verdana;font-size:14px">'.substr($sozluk->convert($entry->yazar),0,15).'<br><font style="verdana" size="1">'.$entry->tarih.'</font></span>
		</div>';
	}
}
else if($_POST['process']=='gelen'){
	$kim = $_SESSION['user'];
	$gelen = DB::get('SELECT * FROM message WHERE kime = ? and d2 = 0 ORDER BY id DESC',array($kim));
	echo '<div class="ui-block-solo" id="gelen_msj">';
	foreach ($gelen as $mesaj) {
		$gonderen = DB::getRow('SELECT * FROM user WHERE temiz = ?',array($mesaj->kimden)); 
		echo '
		<div class="ui-block-solo" style="border-bottom:1px solid #DBDBDB;margin-top:15px">
    		<div class="ui-block-solo"><img src="http://sozluksau.com/img/'.$gonderen->img.'" style="float:left;width:30px;height:30px;"><b style="float:left;margin-top:5px;margin-left:10px">'.$sozluk->convert($gonderen->ad).'</b></div><div style="clear:both"></div>
    		<div class="ui-block-solo" style="padding:5px">'.$mesaj->msj.'</div>
    		<div class="ui-block-solo" style="padding:5px;text-align:right"><i class="yanitla" id="'.$gonderen->temiz.'" style="margin-left:10px">yanıtla</i><i class="sil_mesaj" id="'.$mesaj->id.'" style="margin-left:10px">sil</i></div>
		</div>
		';
	}
	echo '</div>';
}else if($_POST['process']=='baslik_ad'){
	$baslik = $_POST['baslik'];
	$baslik = DB::getVar('SELECT goster FROM basliktar WHERE ad = ?',array($baslik));
	echo $sozluk->convert($baslik);
}
else if($_POST['process']=='giden'){
	$kim = $_SESSION['user'];
	$gelen = DB::get('SELECT * FROM message WHERE kimden = ? and d1 = 0 ORDER BY id DESC',array($kim));
	echo '<div class="ui-block-solo" id="giden_msj">';
	foreach ($gelen as $mesaj) {
		$gonderen = DB::getRow('SELECT * FROM user WHERE temiz = ?',array($mesaj->kime)); 
		echo '
		<div class="ui-block-solo" style="border-bottom:1px solid #DBDBDB;margin-top:15px">
    		<div class="ui-block-solo"><img src="http://sozluksau.com/img/'.$gonderen->img.'" style="float:left;width:30px;height:30px;"><b style="float:left;margin-top:5px;margin-left:10px">'.$sozluk->convert($gonderen->ad).'</b></div><div style="clear:both"></div>
    		<div class="ui-block-solo" style="padding:5px">'.$mesaj->msj.'</div>
    		<div class="ui-block-solo" style="padding:5px;text-align:right"><i class="sil_mesaj" id="'.$mesaj->id.'" style="margin-left:10px">sil</i></div>
		</div>
		';
	}
	echo '</div>';
}
else if($_POST['process']=='kontrol'){
	$say = DB::getVar('SELECT Count(id) FROM chat');
	echo $say;
}
else if($_POST['process']=='chat_send'){
	$mesaj = $_POST['msj'];
	$yazan = $sozluk->temizle($_SESSION['user']);
	$tarih = date("Y-m-d H:i:s");
	$tarih = $sozluk->format_tarih($tarih);
	$ekle  = DB::exec('INSERT INTO chat (yazan,tarih,msj) VALUES (?,?,?)',array($yazan,$tarih,$mesaj));
	$img   = DB::getVar('SELECT img FROM user WHERE temiz = ?',array($yazan));
	echo '<img src="http://sozluksau.com/img/'.$img.'" style="border:1px;margin-left:15px;margin-top:15px;float:left;width:40px;height:40px"><div class="bubble" style="float:left;border-color: #EBEBEB;">'.$sozluk->convert($mesaj).'</div><div style="clear:both"></div>';
}
else if($_POST['process']=='logoff'){
	$nick = $_SESSION['user'];
	$ip   = $_SERVER['REMOTE_ADDR'];
	$online_sil = DB::exec('DELETE FROM online WHERE ad = ? and ip = ?',array($nick,$ip));
	$_SESSION['user']=null;

	echo 1;
}else if($_POST['process']=='mod_yap'){
	$id = $_POST['id'];
	if($_SESSION['yetki']=='admin'){
		$mod_yap = DB::exec('UPDATE user SET yetki = "mod" WHERE id = "'.$id.'"');
		echo 'işlem gerçekleşti';
	}else{
		echo 'bu işlem için yetkin yok';
	}
}
else if($_POST['process']=='onayla'){
	$id = $_POST['id'];
	if($_SESSION['yetki']=='admin' || $_SESSION['yetki']=='mod'){
		$mod_yap = DB::exec('UPDATE user SET yetki = "yazar" WHERE id = "'.$id.'"');
		echo 'işlem gerçekleşti';
	}else{
		echo 'bu işlem için yetkin yok';
	}
}
else if($_POST['process']=='caylak_yap'){
	$id = $_POST['id'];
	if($_SESSION['yetki']=='admin' || $_SESSION['yetki']=='mod'){
		$mod_yap = DB::exec('UPDATE user SET yetki = "caylak" WHERE id = "'.$id.'"');
		echo 'işlem gerçekleşti';
	}else{
		echo 'bu işlem için yetkin yok';
	}	
}else if($_POST['process']=='ucur'){
	$id = $_POST['id'];
	if($_SESSION['yetki']=='admin' || $_SESSION['yetki']=='mod'){
		$mod_yap = DB::exec('UPDATE user SET yetki = "silik" WHERE id = "'.$id.'"');
		echo 'işlem gerçekleşti';
	}else{
		echo 'bu işlem için yetkin yok';
	}
}
else if($_POST['process']=='ekleEntry'){
	if(isset($_SESSION['user'])){
		$metin = strtolower(nl2br($_POST['metin']));
		$bozuk = array("Ç","Ş","İ","Ö","Ğ","Ü");
		$duzgun = array('ç',"ş","i","ö","ğ","ü");
		$metin = str_replace($bozuk, $duzgun, $metin);
		$baslik = $_POST['baslik'];
		$temiz = $sozluk->temizle($baslik);
		$baslikSay = DB::getVar('SELECT count(id) FROM entry WHERE baslik = "'.$temiz.'"');
		if($baslikSay<1){
			if($_SESSION['yetki']=='caylak'){
				echo '1';	
			}else{
			$id = $sozluk->entry_ekle($metin,$baslik);		
			}
			
		}else{
		$id = $sozluk->entry_ekle($metin,$baslik);	
		}
		
		echo $id;	
	}else{
		echo '0';
	}
}
else if($_POST['process']=='editEntry'){
	$metin = nl2br($_POST['metin']);
	$id = $_POST['id'];
	$edit = DB::exec('UPDATE entry SET metin = "'.$metin.'" WHERE id = "'.$id.'"');
	echo $id;
}
else if($_POST['process']=='baslik_sil'){
	$authority = $_SESSION['yetki'];
	if($authority=='admin' || $authority=='mod'){
		$baslik = $_POST['baslik'];
		$affected = DB::exec('DELETE FROM basliktar WHERE ad ="'.$baslik.'"');
		$entryler = DB::exec('DELETE FROM entry WHERE baslik ="'.$baslik.'"');
		if($affected>0) echo '1';
		else echo '2';
	}
	else echo '0';
}else if($_POST['process']=='entrydenMesaj'){
	$to = $_POST['to'];
	echo $sozluk->temizle($sozluk->convert($to));

}
else if($_POST['process']=='baslik_duzenle'){
	$authority = $_SESSION['yetki'];
	if($authority =='admin' || $authority =='mod'){
		$baslik = $_POST['baslik'];
		$yeni = $_POST['yeni'];
		$yeniTemiz = $sozluk->temizle($yeni);
		$affected = DB::exec('UPDATE basliktar SET ad ="'.$yeniTemiz.'",goster = "'.$yeni.'" WHERE ad = "'.$baslik.'"');
		$entryler = DB::exec('UPDATE entry SET baslik ="'.$yeniTemiz.'" WHERE baslik = "'.$baslik.'"');
		if($affected>0) echo $yeniTemiz;
	}
	else echo '0';
}
else if($_POST['process']=='arti')
{
	if(isset($_SESSION['user'])){
		$id = $_POST['id'];
		$entry = DB::getrow('SELECT * FROM entry WHERE id ="'.$id.'"');
		if($entry->yazar == $_SESSION['user']) echo 'egonu mu tatmin ediyosun müdür?';
		else{
		$kontrol = DB::getVar('SELECT Count(id) FROM votes WHERE entry = "'.$id.'" and user = "'.$_SESSION['user'].'"');
		if($kontrol>0) echo 'oy kullanılmadı. bkz: tek oy kuralı';
		else{
			$arttir = DB::exec('UPDATE entry SET puan = puan + 10 WHERE id = "'.$id.'"');	
			$arttir = DB::exec('UPDATE user SET puan = puan + 10 WHERE id = "'.$id.'"');	
			$logEkle = DB::insert(
				'INSERT INTO votes (user,entry,sahip,tur) VALUES (?, ?, ?,?)',
    			 array($_SESSION['user'], $id,$entry->yazar,'arti')
			);
			
			$tarih = date('Y-m-d H:i:s');
			$tarih = $sozluk->format_tarih($tarih);
			$toTemiz   = $sozluk->temizle($sozluk->convert($entry->yazar));
			$mesaj = "<a href='../../entry/".$entry->id."'>#".$entry->id."</a> numaralı entryne <strong>artı</strong> oy verildi";
			$ekle = DB::query('INSERT INTO message (kimden,kime,msj,tarih) VALUES (?,?,?,?)',array('sozlukdroid',$toTemiz,$mesaj,$tarih));
			$bildirim = DB::exec('UPDATE user SET msj = msj + 1 WHERE temiz = "'.$toTemiz.'"');
			echo 'ttlm çk gzl çkmssn :)';	
		} 
	}		
	}else{
		echo 'tekrar giriş yapman gerek';
	}
}
else if($_POST['process']=='eksi')
{
	if(isset($_SESSION['user'])){
		$id = $_POST['id'];
		$entry = DB::getrow('SELECT * FROM entry WHERE id ="'.$id.'"');
		if($entry->yazar == $_SESSION['user']) echo 'kendi bacağına sıktın az önce';
		else{
		$kontrol = DB::getVar('SELECT Count(id) FROM votes WHERE entry = "'.$id.'" and user = "'.$_SESSION['user'].'"');
		if($kontrol>0) echo 'oy kullanılmadı. bkz: tek oy kuralı';
		else{
			$arttir = DB::exec('UPDATE entry SET puan = puan - 10 WHERE id = "'.$id.'"');
			$arttir = DB::exec('UPDATE user SET puan = puan - 10 WHERE id = "'.$id.'"');		
			$logEkle = DB::insert(
				'INSERT INTO votes (user,entry,sahip,tur) VALUES (?, ?, ?,?)',
    			 array($_SESSION['user'], $id, $entry->yazar,'eksi')
			);
			$tarih = date('Y-m-d H:i:s');
			$tarih = $sozluk->format_tarih($tarih);
			$toTemiz   = $sozluk->temizle($sozluk->convert($entry->yazar));
			$mesaj = "<a href='../../entry/".$entry->id."'>#".$entry->id."</a> numaralı entryne <strong>eksi</strong> oy verildi";
			$ekle = DB::query('INSERT INTO message (kimden,kime,msj,tarih) VALUES (?,?,?,?)',array('sozlukdroid',$toTemiz,$mesaj,$tarih));
			$bildirim = DB::exec('UPDATE user SET msj = msj + 1 WHERE temiz = "'.$toTemiz.'"');
			echo 'yapma';	
		} 
	}		
	}else{
		echo 'tekrar giriş yapman gerek';
	}
}
else if($_POST['process']=='fav')
{
	if(isset($_SESSION['user'])){
		$id = $_POST['id'];
		$entry = DB::getrow('SELECT * FROM entry WHERE id ="'.$id.'"');
		if($entry->yazar == $_SESSION['user']) echo 'kendini beğenmiş detected';
		else{
			$kontrol = DB::getVar('SELECT Count(id) FROM fav WHERE entry = "'.$id.'" and yazar = "'.$_SESSION['user'].'"');
			if($kontrol>0) echo 'bu zaten favorilerinde';
			else{
				$arttir = DB::exec('UPDATE entry SET puan = puan + 50 WHERE id = "'.$id.'"');
				$arttir = DB::exec('UPDATE user SET puan = puan + 50 WHERE id = "'.$id.'"');		
				$logEkle = DB::insert(
					'INSERT INTO fav (yazar,entry) VALUES (?, ?)',
    				 array($_SESSION['user'], $id)
				);
				$tarih = date('Y-m-d H:i:s');
				$tarih = $sozluk->format_tarih($tarih);
				$toTemiz   = $sozluk->temizle($entry->yazar);
				$mesaj = "<strong><a href='../../yazar/".$sozluk->temizle($_SESSION['user'])."/'>".$_SESSION['user']."</a></strong> adlı yazar <a href='../../entry/".$entry->id."'>#".$entry->id."</a> numaralı entryni favorilerine ekledi.";
				$ekle = DB::query('INSERT INTO message (kimden,kime,msj,tarih) VALUES (?,?,?,?)',array('sozlukdroid',$toTemiz,$mesaj,$tarih));
				$bildirim = DB::exec('UPDATE user SET msj = msj + 1 WHERE temiz = "'.$toTemiz.'"');
				echo 'seni seçtim iskoçyalı';
			}
		}
	}else{
		echo 'tekrar giriş yapman gerek';
	}
}
else if($_POST['process']=='sikayet'){
	$sikayet = $_POST['sikayet'];
	$bozuk = array('ı',"ö","ç","ş","ğ","ü");
	$temiz = array('i',"o","c","s","g","u");
	$sikayet = str_replace($bozuk,$temiz,$sikayet);
	$id = $_POST['id'];
	if(isset($_SESSION['user'])){
		$ad = $_SESSION['user'];
	}else{
		$ad = 'ziyaretçi';
	}
	$ekle = DB::query('INSERT INTO sikayet (neden,entry,user) VALUES ("'.$sikayet.'","'.$id.'","'.$ad.'")');
	echo '1';
}
else if($_POST['process']=='entry_sil'){
	$id = $_POST['id'];
	$authority = $_SESSION['yetki'];
	if($authority =='admin' || $authority=='mod'){
		$sil = DB::exec('UPDATE entry SET deleted = "1" WHERE id = "'.$id.'"');	
		echo '1';
	}else{
		$yazar = DB::getVar('SELECT yazar FROM entry WHERE id = "'.$id.'"');
		if($yazar==$_SESSION['user']){
			$sil = DB::exec('UPDATE entry SET deleted = "1" WHERE id = "'.$id.'"');	
			echo '1';
		}else{
			echo '0';
		}
	}	
}
else if($_POST['process']=='message_send'){
	$mesaj = $_POST['msj'];
	$to = $_POST['to'];
	$toTemiz = $sozluk->temizle($to);
	if(isset($_SESSION['user'])){
		if($to == $_SESSION['user']){
			echo 'şizofren detected';
		}else{
		$tarih = date('Y-m-d H:i:s');
		$tarih = $sozluk->format_tarih($tarih);
		$fromTemiz = $sozluk->temizle($_SESSION['user']);	
		$kontrol = DB::getVar('SELECT Count(id) FROM user WHERE temiz = "'.$toTemiz.'"');
		if($kontrol>0){
			$ekle = DB::query('INSERT INTO message (kimden,kime,msj,tarih) VALUES (?,?,?,?)',array($fromTemiz,$toTemiz,$mesaj,$tarih));
			$bildirim = DB::exec('UPDATE user SET msj = msj + 1 WHERE temiz = "'.$toTemiz.'"');
			echo 'mesaj gönderildi';
		}else{
			echo 'hatalı alıcı adı girdin';
		}	
		}
		
	}else{
		echo 'yeniden oturum açman gerek';
	}
}else if($_POST['process']=='del_mesaj'){
	$id = $_POST['id'];
	$query = DB::getRow('SELECT * FROM message WHERE id = "'.$id.'"');
	if($query->kimden == $sozluk->temizle($_SESSION['user'])){
		$sil = DB::exec('UPDATE message SET d1 = "1" WHERE id = "'.$id.'"');
		echo 'mesaj silindi';
	}else if($query->kime == $sozluk->temizle($_SESSION['user'])){
		$sil = DB::exec('UPDATE message SET d2 = "1" WHERE id = "'.$id.'"');
		echo 'mesaj silindi';
	}	
}else if($_POST['process'] == 'iletidegistir'){
	$ileti = $_POST['ileti'];
	$guncelle = DB::exec('UPDATE user SET ileti = "'.$ileti.'" WHERE ad = "'.$_SESSION['user'].'"');
	echo 'güncellendi';
}else if($_POST['process']=='change_pass'){
	$old = $_POST['old'];
	$new = $_POST['yeni'];
	$data = DB::getRow('SELECT * FROM user WHERE ad = "'.$_SESSION['user'].'"');
	if($data->pass == md5($old)){
		$update = DB::exec('UPDATE user SET pass = "'.md5($new).'" WHERE ad = "'.$_SESSION['user'].'"');
		echo 'parola değiştirildi';
	}else{
		echo 'eski parola hatalı';
	}
}
else if($_POST['process']=='change_mail'){
	$old = $_POST['pass'];
	$new = $_POST['yeni'];
	$data = DB::getRow('SELECT * FROM user WHERE ad = "'.$_SESSION['user'].'"');
	if($data->pass == md5($old)){
		$kontrol = DB::getVar('SELECT Count(id) FROM user WHERE mail = "'.$new.'"');
		if($kontrol<1){
		$update = DB::exec('UPDATE user SET mail = "'.$new.'" WHERE ad = "'.$_SESSION['user'].'"');
		echo 'mail değiştirildi';	
	}else{
		echo 'bu e-posta kullanılıyor';
	}
		
	}else{
		echo 'parola hatalı';
	}
}else if($_POST['process']=='register'){
	$nick = strtolower($_POST['nick']);
	$nick = trim($nick);
	$bozuk = array("Ç","Ş","İ","Ö","Ğ","Ü");
	$duzgun = array('ç',"ş","i","ö","ğ","ü");
	$gorunecek = str_replace($bozuk, $duzgun, $nick);
	$nick = $sozluk->temizle($nick);
	$pass = md5($_POST['pass']);
	$mail = $_POST['mail'];
	$cins = $_POST['cins'];
	$dtarihi = $_POST['dtarihi'];
	$kontrol1 = DB::getVar('SELECT Count(id) FROM user WHERE temiz = "'.$nick.'"');
	if($kontrol1<1){
		$kontrol2 = DB::getVar('SELECT Count(id) FROM user WHERE mail = "'.$mail.'"');
		if($kontrol2<1){
			$temiz = $sozluk::temizle($nick);
			$nick = str_replace('-',' ',$nick);
			$ekle = DB::exec('INSERT INTO user (ad,pass,mail,cins,dyil,temiz) VALUES (?,?,?,?,?,?)',array($nick,$pass,$mail,$cins,$dtarihi,$temiz));
			echo '1';
		}else{
			echo 'bu mail adresi kullanılıyor';
		}
	}else{
		echo 'bu kullanıcı adı kullanılıyor';
	}
	$temiz = $sozluk::temizle($nick);
	$ekle = DB::exec('INSERT INTO user (ad,pass,mail,cins,dyil,temiz) VALUES (?,?,?,?,?)',array($nick,$pass,$mail,$cins,$dtarihi,$temiz));

}
else if($_POST['process']=='remember_pass'){
	$eposta = $_POST['mail'];
	$kontrol = DB::getVar('SELECT Count(id) FROM user WHERE mail = "'.$eposta.'"');
	if($kontrol<1){
		echo 'böyle bir mail adresi yok';
	}else{
		$yeni = rand(111111,999999);
		$sifre = md5($yeni);
		$degistir = DB::exec('UPDATE user SET pass = "'.$sifre.'" WHERE mail = "'.$eposta.'"');
		
		$mail = new PHPMailer();
		$mail->IsSMTP();
		$mail->SMTPAuth = true;
		$mail->Host = 'smtp.sozluksau.com';
		$mail->Port = 587;
		$mail->Username = 'destek@sozluksau.com';
		$mail->Password = 'Gorkem243';
		$mail->SetFrom($mail->Username, 'sozluksau.com');
		$mail->AddAddress($eposta, 'pek muhterem yazar');
		$mail->CharSet = 'UTF-8';
		$mail->Subject = 'sozluksau.com parola hatırlatma';
		$mail->MsgHTML('parolan değiştirildi geçici parolan <b>'.$yeni.'</b><br>parolanı kullanıcı paneline girip değiştirebilirsin<br><br>sozluksau.com');
		if($mail->Send()) {
    	echo 'mail gönderildi!';
		} else {
    	echo 'mail gönderilirken bir hata oluştu: ' . $mail->ErrorInfo;
		}
	}
}
else if($_POST['process']=='baslik_ekle'){
	$syc = $_POST['syc'];
	$alt = $syc*350;
	$basliklar = DB::get('SELECT * FROM basliktar ORDER BY tar LIMIT '.$alt.',350');
	foreach ($basliklar as $baslik) {
		$kontrol = DB::getVar('SELECT count(id) FROM entry WHERE baslik ="'.$baslik->ad.'"');
		if($kontrol>0){
			$son = ceil($kontrol/25);
			$temiz = $sozluk->convert($baslik->goster);
			echo '<a href="../../baslik/'.$baslik->ad.'/'.$son.'"><li class="'.$baslik->id.'">'.$temiz.'</li></a>';
		}
	}
	$sayac = $syc+1;
	echo '<a class="baslik_ekle" data-bslk="'.$sayac.'"><li><strong>daha fazla başlık! daha fazla!</strong></li></a>';
}else if($_POST['process']=='bugun'){
	$basliklar = DB::get('SELECT * FROM basliktar ORDER BY tar DESC LIMIT 350');
	 	foreach($basliklar as $baslik){
    		$count = DB::getVar('SELECT COUNT(id) FROM entry WHERE deleted = "0" and baslik = "'.$baslik->ad.'"');
    		if($count>0){
    			$temiz = $sozluk->convert($baslik->goster);
    			$son = ceil($count/25);
    			$today = date('Y-m-d');
				$bugun = DB::getVar('SELECT count(id) FROM entry WHERE baslik = "'.$baslik->ad.'" and deleted = "0" and date LIKE "'.$today.'%"');
				if($bugun>0){
				echo '<a href="../../baslik/'.$baslik->ad.'/'.$son.'"><li class="'.$baslik->id.'">'.$temiz.'<span id="entrySayi" style="float:right">'.$bugun.'</span></li></a>';	
				}else{
				echo '<a href="../../baslik/'.$baslik->ad.'/'.$son.'"><li class="'.$baslik->id.'">'.$temiz.'</li></a>';
				}
    			
    		}
    	}
    	echo '<a class="baslik_ekle" data-bslk="1"><li><strong>daha fazla başlık! daha fazla!</strong></li></a>';
}else if($_POST['process']=='dun'){
	$day = $sozluk->dun();
	$basliklar = DB::get('SELECT * FROM basliktar WHERE tar LIKE "'.$day.'%" ORDER BY tar DESC LIMIT 350');
	 	foreach($basliklar as $baslik){
    		$count = DB::getVar('SELECT COUNT(id) FROM entry WHERE deleted = "0" and baslik = "'.$baslik->ad.'"');
    		if($count>0){
    			$temiz = $sozluk->convert($baslik->goster);
    			$son = ceil($count/25);
    			
				$dun = DB::getVar('SELECT count(id) FROM entry WHERE baslik = "'.$baslik->ad.'" and deleted = "0" and date LIKE "'.$day.'%"');
				if($dun>0){
				echo '<a href="../../baslik/'.$baslik->ad.'/'.$son.'"><li class="'.$baslik->id.'">'.$temiz.'<span id="entrySayi" style="float:right">'.$dun.'</span></li></a>';	
				}else{
				echo '<a href="../../baslik/'.$baslik->ad.'/'.$son.'"><li class="'.$baslik->id.'">'.$temiz.'</li></a>';
				}
    		}
    	}
    	echo '<a class="baslik_ekle" data-bslk="1"><li><strong>daha fazla başlık! daha fazla!</strong></li></a>';
}
else if($_POST['process']=='random'){
	$basliklar = DB::get('SELECT * FROM basliktar ORDER BY RAND() DESC LIMIT 350');
	 	foreach($basliklar as $baslik){
    		$count = DB::getVar('SELECT COUNT(id) FROM entry WHERE deleted = "0" and baslik = "'.$baslik->ad.'"');
    		if($count>0){
    			$temiz = $sozluk->convert($baslik->goster);
    			$son = ceil($count/25);

    			echo '<a href="../../baslik/'.$baslik->ad.'/'.$son.'"><li class="'.$baslik->id.'">'.$temiz.'</li></a>';
    		}
    	}
}else if($_POST['process']=='ara'){
	$ara = $_POST['key'];
	$ara = $sozluk->temizle($ara);
	$basliklar = DB::get('SELECT * FROM basliktar WHERE ad LIKE "%'.$ara.'%" LIMIT 25');
	echo '<li><strong>benzer başlıklar</strong></li>';
	foreach ($basliklar as $baslik) {
		$count = DB::getVar('SELECT COUNT(id) FROM entry WHERE deleted = "0" and baslik = "'.$baslik->ad.'"');
    		if($count>0){
    			$temiz = $sozluk->convert($baslik->goster);
    			$son = ceil($count/25);

    			echo '<a href="../../baslik/'.$baslik->ad.'/'.$son.'"><li class="'.$baslik->id.'">'.$temiz.'</li></a>';
    		}
	}
	echo '<li><strong>yazar önerileri</strong></li>';
	$yazarlar = DB::get('SELECT * FROM user WHERE temiz LIKE "%'.$ara.'%" LIMIT 25');
	foreach ($yazarlar as $yazar) {
				$temiz = $sozluk->convert($yazar->ad);
    			$son = ceil($count/25);
				echo '<a href="../../yazar/'.$yazar->temiz.'/"><li>'.$temiz.'</li></a>';
    		}
}


?>