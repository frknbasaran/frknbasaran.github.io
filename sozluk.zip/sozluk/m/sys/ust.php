<?
session_start();
function temizle($tr1) {
        $turkce=array("ş","Ş","ı","ü","Ü","ö","Ö","ç","Ç","ş","Ş","ı","ğ","Ğ","İ","ö","Ö","Ç","ç","ü","Ü","%20","?");
        $duzgun=array("s","S","i","u","U","o","O","c","C","s","S","i","g","G","I","o","O","C","c","u","U","-"," ");
        $tr1=str_replace($turkce,$duzgun,$tr1);
        $tr1 = preg_replace("@[^a-z0-9\-_şıüğçİŞĞÜÇ]+@i","-",$tr1);
        return $tr1;
    }
     function convert($d){
        $bozuk = array("Ã¶","Ã¼","ÄŸ","Ã§","ÅŸ","Ä±","â€™","<script>","</script>");
        $duzgun = array("ö","ü","ğ","ç","ş","ı","'"," "," ");
        $sonuc = str_replace($bozuk,$duzgun,$d);
        return $sonuc;
    }
echo '
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
</head>
<body>
<nav class="navigation-bar dark fixed-top shadow">
    <nav class="navigation-bar-content">
        <div class="element">
            <a style="color:white" href="../../hakkinda">sozluksau.com</a>
             
        </div>

        <span class="element-divider"></span>
        <a class="element brand bugun" style="cursor:pointer"><span class="icon-spin"></span></a>
        <span class="element-divider"></span>
        <a class="element brand dun" style="cursor:pointer"><span class="icon-history"></span></a>
        <span class="element-divider"></span>
        <a class="element brand random" style="cursor:pointer"><span class="icon-lightning"></span></a>
        <span class="element-divider"></span>
<div class="element input-element">
            
                <div class="input-control text" style="margin-left:100px">
                    <input type="text" id="ara" style="width:300px" placeholder="baslik,yazar ara">
                    <button class="btn-search"></button>
                </div>
            
        </div>';
        if(isset($_SESSION['user'])){
            $yetki = DB::getVar('SELECT yetki FROM user WHERE ad = "'.$_SESSION['user'].'"');
            if($yetki=='mod' || $yetki=='admin'){
            echo '
            <div class="element place-right">
            <a class="dropdown-toggle" href="#">
                <span class="icon-cog"></span>
            </a>
            <ul class="dropdown-menu place-right" data-role="dropdown">
                <li><a href="../../duyuru">duyurular</a></li>
                <li><a href="../../yonetim">yönetim paneli</a></li>
                <li><a href="../../panel">kullanıcı paneli</a></li>
                <li class="divider"></li>
                <li><a id="logoff">burayı terk et</a></li>
            </ul>
            </div>';
            }else{
                echo '
            <div class="element place-right">
            <a class="dropdown-toggle" href="#">
                <span class="icon-cog"></span>
            </a>
            <ul class="dropdown-menu place-right" data-role="dropdown">
                <li><a href="../../duyuru">duyurular</a></li>
                <li><a href="../../panel">kullanıcı paneli</a></li>
                <li class="divider"></li>
                <li><a id="logoff">burayı terk et</a></li>
            </ul>
            </div>';

            }
            echo     '<span class="element-divider place-right"></span>';
            $msj = DB::getVar('SELECT msj FROM user WHERE ad = "'.$_SESSION['user'].'"');
            if($msj>0){
                echo '<a class="element place-right" style="background-color:#EBEBEB" id="messages" href="../../mesajlar"><span class="icon-mail" style="color:#135F99"></span></a>';
            }else{
                echo '<a class="element place-right" id="messages" href="../../mesajlar"><span class="icon-mail"></span></a>';
            }
            $temiz = temizle(convert($_SESSION['user']));
            echo '<span class="element-divider place-right"></span>
            <a class="element place-right" id="messages" href="http://fizy.com/live/sozluksau" target="_new"><span class="icon-music"></span></a>
            <span class="element-divider place-right"></span>
            <a class="element place-right" href="../../istatistik"><span class="icon-stats-up"></span></a>
            <span class="element-divider place-right"></span>
            <a href="../../yazar/'.$temiz.'/" style="color:white"><button class="element image-button image-left place-right">
            ';
            $yazar = convert($_SESSION['user']);

            $img = DB::GetVar('SELECT img FROM user WHERE ad = "'.$_SESSION['user'].'"');
            if(strlen($yazar)>10){
                echo substr($yazar,0,10).'..';
            }else{
                echo $yazar;
            }
            echo '
            <img src="/img/'.$img.'"/>
            </button></a>
            ';
        }else{
            echo '
            <span  class="element-divider place-right"></span>
            <a class="element place-right" id="login" href="#"><span class="icon-user-2"></span></a>
            <span class="element-divider place-right"></span>
            <a class="element place-right" id="messages" href="http://fizy.com/live/sozluksau" target="_new"><span class="icon-music"></span></a>
            <span class="element-divider place-right"></span>
            <a class="element place-right" href="../../istatistik"><span class="icon-stats-up"></span></a>';
        }
        if(isset($_SESSION['user'])){
            $online = DB::getVar('SELECT Count(id) FROM online');
            echo '</nav>

</nav>
<a href="../../online"><button style="margin-top:45px;float:right" class="inverse">sözlükte '.$online.' kişi var</button></a>
</body>
</html>
';
        }else{
        echo '</nav>
</nav>
</body>
</html>
';        
        }
    

?>