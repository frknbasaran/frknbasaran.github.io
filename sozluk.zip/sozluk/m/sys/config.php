<?php
/*
*
* Veritabanı bağlantısı için
* gerekli bağlantı bilgilerinin
* bulunduğu ayar dosyası.
*
*/
date_default_timezone_set('Europe/Istanbul');

define('MYSQL_HOST',	'localhost');
define('MYSQL_DB',		'sozluksa_db1234');
define('MYSQL_USER',	'sozluksa_adm123');
define('MYSQL_PASS',	'Ea8H3C8h');
include 'db.php';
