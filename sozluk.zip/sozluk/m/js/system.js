$(document).ready(function(){

			$('#login_but').click(function(){
				var mail = $('#mail').val();
				var pass = $('#pass').val();
				$.post('http://m.sozluksau.com/ajax',{process:'login',mail:mail,pass:pass},function(e){
					if(e==0){
						alert('bilgilerin hatalı');
					}else if(e==1){
						window.location="../";
					}else{
						alert('bişeyler ters gitti');
					}
				});
			});

			$('body').on('click','.entry_arti',function(){
				var id = $(this).attr('id');
				$.post('http://m.sozluksau.com/ajax',{process:'arti',id:id},function(e){
					alert(e);
				});
			});

			$('body').on('click','.entry_eksi',function(){
				var id = $(this).attr('id');
				$.post('http://m.sozluksau.com/ajax',{process:'eksi',id:id},function(e){
					alert(e);
				});
			});

			$('body').on('click','.entry_fav',function(){
				var id = $(this).attr('id');
				$.post('http://m.sozluksau.com/ajax',{process:'fav',id:id},function(e){
					alert(e);
				});
			});

			

			$('#yeni_msj').click(function(){
				$('#gelen_msj').remove();
				$('#giden_msj').remove();
				$('#mesaj_yaz').css('display','block');
			});

			$('#gelen').click(function(){
				$('#giden_msj').remove();
				$('#mesaj_yaz').css('display','none');
				$.post('http://m.sozluksau.com/ajax',{process:'gelen'},function(e){
					$('#mesaj_govde').append(e);
				});
			});

			$('.baslik_baglanti').click(function(){
				var baslik = $(this).attr('id');
				$('#entryler').empty();
				$.post('http://m.sozluksau.com/ajax',{process:'entry_liste',baslik:baslik},function(e){
					$('#entryler').append(e);
				});
				$.post('http://m.sozluksau.com/ajax',{process:'baslik_ad',baslik:baslik},function(e){
					$('#entry_baslik').empty().append(e);
				});
			});

			$('#giden').click(function(){
				$('#mesaj_yaz').css('display','none');
				$('#gelen_msj').remove();
				$.post('http://m.sozluksau.com/ajax',{process:'giden'},function(e){
					$('#mesaj_govde').append(e);
				});
			});

			$('body').on('click','.yanitla',function(){
				$('#gelen_msj').remove();
				var to = $(this).attr('id');
				$('#kime').val(to);
				$('#mesaj_yaz').css('display','block');
			});

			$('body').on('click','.sil_mesaj',function(){
				var id = $(this).attr('id');
				$.post('http://m.sozluksau.com/ajax',{process:'del_mesaj',id:id},function(e){
					alert(e);
				});
				
			});

			
});