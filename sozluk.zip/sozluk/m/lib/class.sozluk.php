<?
// saü sözlük için wozniak tarafından geliştirilmiştir.
class sozluk
{
	public function temizle($tr1) {
		$turkce=array("ş","Ş","ı","ü","Ü","ö","Ö","ç","Ç","ş","Ş","ı","ğ","Ğ","İ","ö","Ö","Ç","ç","ü","Ü","%20","?");
		$duzgun=array("s","S","i","u","U","o","O","c","C","s","S","i","g","G","I","o","O","C","c","u","U","-"," ");
		$tr1=str_replace($turkce,$duzgun,$tr1);
		$tr1 = preg_replace("@[^a-z0-9\-_şıüğçİŞĞÜÇ]+@i","-",$tr1);
		return $tr1;
	}

	public function br2ln($tr1) {
		$turkce=array("<br />");
		$duzgun=array("");
		$tr1=str_replace($turkce,$duzgun,$tr1);
		return $tr1;
	}
	public function dun(){
		$tarih = date('Y-m-d');
		$gun = substr($tarih,8,2);
		$ay  = substr($tarih,5,2);
		$yil = substr($tarih,0,4);
		if($gun<=10){
		$gun = $gun-1;	
		return $yil.'-'.$ay.'-0'.$gun;	
		}else{
		$gun = $gun-1;
		return $yil.'-'.$ay.'-'.$gun;
		}
		
		
	}
	public function convert($d){
    	$bozuk = array("Ã‡","Ã¶","Ã¼","ÄŸ","Ã§","ÅŸ","Ä±","â€™","<script>","</script>");
    	$duzgun = array("ç","ö","ü","ğ","ç","ş","ı","'"," "," ");
    	$sonuc = str_replace($bozuk,$duzgun,$d);
    	return $sonuc;
	}

	public function baslik_sirala(){
		
		$basliklar = DB::get('SELECT * FROM basliktar ORDER BY tar DESC LIMIT 350');
		echo '
		<ul data-role="listview" data-filter="true" data-count-theme="b" data-filter-placeholder="başlıklarda ara"  data-inset="true">
		';
    	
    	foreach($basliklar as $baslik){
    		$count = DB::getVar('SELECT COUNT(id) FROM entry WHERE deleted = "0" and baslik = "'.$baslik->ad.'"');
    		if($count>0){
    			$temiz = $this->convert($baslik->goster);
    			$son = ceil($count/25);
    			$today = date('Y-m-d');
				$bugun = DB::getVar('SELECT count(id) FROM entry WHERE baslik = "'.$baslik->ad.'" and deleted = "0" and date LIKE "'.$today.'%"');
				if($bugun>0){
				echo '<li class="baslik_baglanti" id="'.$baslik->ad.'"><a href="#entry">'.$temiz.'<span class="ui-li-count">'.$bugun.'</span></a></li>';
				}else{
				echo '<li class="baslik_baglanti" id="'.$baslik->ad.'"><a href="#entry">'.$temiz.'</a></li>';
				}
			}
    	}
    		
		echo '</ul>';
		

	 	
	}

	public function mobil_gelen_msj(){
		$kim = $_SESSION['user'];
		$gelen = DB::get('SELECT * FROM message WHERE kime = ? and deleted = 0 ORDER BY id DESC',array($kim));
		foreach ($gelen as $mesaj) {
			$gonderen = DB::getRow('SELECT * FROM user WHERE temiz = ?',array($mesaj->kimden)); 
			echo '
			<div class="ui-block-solo" style="border-bottom:1px solid #DBDBDB;margin-top:15px">
    			<div class="ui-block-solo"><img src="http://sozluksau.com/img/'.$gonderen->img.'" style="float:left;width:30px;height:30px;"><b style="float:left;margin-top:5px;margin-left:10px">'.$sozluk->convert($gonderen->ad).'</b></div><div style="clear:both"></div>
    			<div class="ui-block-solo" style="padding:5px">'.$mesaj->msj.'</div>
    			<div class="ui-block-solo" style="padding:5px;text-align:right"><i class="yanitla" id="'.$gonderen->temiz.'" style="margin-left:10px">yanıtla</i><i class="sil_mesaj" id="'.$mesaj->id.'" style="margin-left:10px">sil</i></div>
			</div>';
		}
	}

	public function mobil_ust(){
		if(isset($_SESSION['user'])){
	echo '
<div data-role="header" data-position="fixed" style="overflow:hidden;">
<h1>saü sözlük mobil</h1>
    <a href="#mesaj" data-transition="flip" data-icon="mail" class="ui-btn-left">mesajlar</a>
    <a href="#right_panel" data-transition="flip" data-icon="gear" class="ui-btn-right">ayarlar</a>
    <!-- /navbar -->
</div>
	';
}else{
	echo '<div data-role="header" data-position="fixed">
		<h1>saü sözlük mobil</h1>
		<a href="" data-rel="back" data-transition="flip" class="ui-btn ui-btn-left ui-alt-icon ui-nodisc-icon ui-corner-all ui-btn-icon-notext ui-icon-carat-l">Back</a>
		<a href="#login" data-icon="user" data-transition="flip" class="ui-btn-right">Giriş</a>
		
</div>';
}
	}

	public function entry_evir_cevir($metin){
		
		$desen = "(\[l:(.*)\]\s?)";
		$replace = '<a target="_new" href="$1">$1</a>';
		$metin = preg_replace($desen, $replace, $metin);
		$desen = "(\[b:(.*):(.*)\]\s?)";
		$replace = '<a target="_new" href="$1">$2</a>';
		$metin = preg_replace($desen, $replace, $metin);
		$desen = "(\[bkz:(.*?)\])";
		$replace = '(bkz:<a href="../../baslik/$1/">$1</a>)';
		$metin = preg_replace($desen, $replace, $metin);
		$desen = "(\[\*\:(.*)\]\s?)";
		$replace = '<a href="../../baslik/$1/" class="yildizli" original-title="$1">*</a>';
		$metin = preg_replace($desen, $replace, $metin);
		$desen = "(\[s:(.*)\]\s?)";
		$replace = '<br>----<a href="../../baslik/spoiler/" class="yildizli" original-title="spoiler">spoiler</a>----<br>$1<br>----<a href="../../baslik/spoiler" class="yildizli" original-title="spoiler">spoiler</a>----';
		return preg_replace($desen, $replace, $metin);
	}
	public function bugun(){
		$today = date('Y-m-d');
		$bugun = DB::getVar('SELECT count(id) FROM entry WHERE date LIKE "'.$today.'%"');
		return $bugun;
	}
	public function entry_getir($baslik,$syf){
		$temiz = $this->temizle($baslik);
		$alt = ($syf*25)-25;
		
		$count = DB::getVar('SELECT count(*) FROM entry WHERE deleted = "0" and baslik = "'.$temiz.'"');
		if($count>0){
			$gorunen = DB::getVar('SELECT goster FROM basliktar WHERE ad = "'.$temiz.'" LIMIT 1');
			if(isset($_SESSION['user'])){
			$authority = $_SESSION['yetki'];
			if($authority=='mod' || $authority=='admin') echo '<h2 style="float:left">'.$this->convert($gorunen).'</h2><span class="baslik_islem"><i data-ad="'.$_GET['ad'].'" class="baslik_sil">sil</i><i data-ad="'.$_GET['ad'].'" class="baslik_duzenle">düzenle</i></span><div style="clear:both"></div>';
			else echo '<h2>'.$this->convert($gorunen).'</h2>';
			}else{
				echo '<h2>'.$this->convert($gorunen).'</h2>';
			} 
			
			$entryler = DB::get('SELECT * FROM entry WHERE baslik = "'.$temiz.'" and deleted = 0 ORDER BY id LIMIT '.$alt.',25');
			$syc=($syf-1)*25;
			echo '<div style="width:80%">
							<div style="width:70px;float:right;margin-top:-35px" class="input-control select">
    							<select data-syf="'.$baslik.'" class="sayfa">';
    							$sayi = ceil($count/25);
        						for($i=1;$i<=$sayi;$i++){
        							if($i==$syf){echo '<option selected value="'.$i.'">'.$i.'</option>';}
        							else{echo '<option value="'.$i.'">'.$i.'</option>';}
        						}
        		echo '</select></div></div>';
			foreach($entryler as $entry){
				$syc++;
				echo '<font id="entry_no" class="'.$entry->id.'" size="1">'.$syc.'</font>';
    			$metin = strtolower($this->convert($entry->metin));
    			$yazilacak = $this->entry_evir_cevir($metin);
    			echo '
    			<div class="entry" id="'.$entry->id.'">
    			<p>'.$yazilacak.'</p>';
    			if(isset($_SESSION['user'])){
    				$authority = $_SESSION['yetki'];
    				echo '<br>';
    				if($authority=='mod' || $authority=='admin') echo '<span class="entry_buttons"><i class="entry_arti" id="'.$entry->id.'">iyi bu</i><i class="entry_eksi" id="'.$entry->id.'">yapma</i><i class="entry_sikayet" id="'.$entry->id.'">şikayet</i><i class="entry_fav" id="'.$entry->id.'">favori</i><i id="'.$entry->yazar.'" class="entry_mesaj">mesaj at</i><i class="entry_sil" id="'.$entry->id.'">sil</i><i class="entry_duzenle" id="'.$entry->id.'">düzenle</i><i class="entry_paylas" id="'.$entry->id.'">paylaş</i></span>';
    				else if($entry->yazar==$_SESSION['user']) echo '<span class="entry_buttons"><i id="'.$entry->id.'" class="entry_arti">iyi bu</i><i id="'.$entry->id.'" class="entry_eksi">yapma</i><i id="'.$entry->id.'" class="entry_sikayet">şikayet</i><i id="'.$entry->id.'" class="entry_fav">favori</i><i id="'.$entry->yazar.'" class="entry_mesaj">mesaj at</i><i id="'.$entry->id.'" class="entry_sil">sil</i><i id="'.$entry->id.'" class="entry_duzenle">düzenle</i><i id="'.$entry->id.'" class="entry_paylas">paylaş</i></span>';
    				else  echo '<span class="entry_buttons"><i id="'.$entry->id.'" class="entry_arti">iyi bu</i><i id="'.$entry->id.'" class="entry_eksi">yapma</i><i id="'.$entry->id.'" class="entry_sikayet">şikayet</i><i id="'.$entry->id.'" class="entry_fav">favori</i><i id="'.$entry->yazar.'" class="entry_mesaj">mesaj at</i><i id="'.$entry->id.'" class="entry_paylas">paylaş</i></span>';
    			}else{
    				 echo '<span class="entry_buttons"><i id="'.$entry->id.'" class="entry_sikayet">şikayet</i><i class="entry_paylas" id="'.$entry->id.'">paylaş</i></span>';
    			}
    			echo '<p class="entry_detay" id="'.$entry->id.'"><font color="silver" size="1">'.$entry->tarih.' </font><font style="cursor:pointer" color="#135F99">';
    				$yazar = $this->convert($entry->yazar);
    				$temiz = $this->temizle($yazar);
    				$yazarId = DB::getVar('SELECT id FROM user WHERE ad = "'.$yazar.'"');
    				echo '<a href="../../yazar/'.$temiz.'/" data-entry="'.$entry->id.'" id="'.$yazarId.'" class="yazar">'.$yazar.'</a></font></p>
    				</div>';
    					
			}
				echo '<div style="width:80%">
							<div style="width:70px;float:right" class="input-control select">
    							<select  data-syf="'.$baslik.'" class="sayfa">';
    							$sayi = ceil($count/25);
        						for($i=1;$i<=$sayi;$i++){
        							if($i==$syf){echo '<option selected value="'.$i.'">'.$i.'</option>';}
        							else{echo '<option value="'.$i.'">'.$i.'</option>';}
        						}
        		echo '</select></div></div>';
		}else{
			echo '<h2>'.$baslik.'</h2>';
			echo '<p><font size="2"><strong>'.$baslik.'</strong> diye bir şey yok burada.<br>ya sen bunu bi tarafından uydurdun ya da bizimkiler henüz tanımlamadılar, ilk tanımlayan sen ol.</font></p>';
		}
	}

	public function entry_say($isim){
		$yazar = DB::getVar('SELECT ad FROM user WHERE temiz = "'.$isim.'"');
		$sayi = DB::getVar('SELECT count(id) FROM entry WHERE yazar = "'.$yazar.'"');
		return $sayi;
	}

	public function puan($isim){
		$yazar = DB::getVar('SELECT ad FROM user WHERE temiz = "'.$isim.'"');
		$entryler = DB::get('SELECT * FROM entry WHERE yazar = "'.$yazar.'"');
		$puan = 0;
		foreach ($entryler as $entry) {
			$puan = $puan + $entry->puan;
		}
		return $puan/10;
	}

	public function entry_giris_alani(){
		if(isset($_SESSION['user'])){
			echo '
			<div class="input-control textarea">
    		<textarea id="entry" placeholder="başlık hakkında dök içini rahatla"></textarea>
			</div>
			<div style="width:80%">
			<div class="button-set" style="float:left">
    		<button id="bkz">bkz</button>
    		<button id="yildiz">*</button>
    		<button id="spoiler">spoiler</button>
    		<button id="link">link</button>
    		</div>
    		<div class="button-set" style="float:right">
    		<button data-baslik="'.$_GET['ad'].'" id="send_entry"><i class="icon-rocket on-left"></i>ateşle</button>
    		</div>
    		</div>
    		
			';
		}else{
			echo '
			<div class="input-control textarea">
    		<textarea id="entry" disabled>giriş yaptıktan sonra entry girebilirsin</textarea>
			</div>
			';
		}
	}
	
	function format_tarih($tarih){
		$gun=substr($tarih,8,2);
		$ay=substr($tarih,5,2);
		$yil=substr($tarih,0,4);
		$saat=substr($tarih,11,2);
		$dk=substr($tarih,14,2);
		return $son_t=$gun.".".$ay.".".$yil." ".$saat.':'.$dk;
	}

	public function entry_ekle($metin,$baslik){
		$tarih = date("Y-m-d H:i:s");
		$tarih = $this->format_tarih($tarih);
		$gorunen = strtolower(trim($baslik));
		$bozuk = array("Ç","Ş","İ","Ö","Ğ","Ü");
		$duzgun = array('ç',"ş","i","ö","ğ","ü");
		$gorunen = str_replace($bozuk, $duzgun, $gorunen);
		$baslik = $this->temizle(trim($baslik));
		$count = DB::getVar('SELECT COUNT(id) FROM basliktar WHERE ad = "'.$baslik.'"');
		if($count<1){
			$id = DB::insert(
				'INSERT INTO basliktar (ad,goster) VALUES (?, ?)',
    			 array($baslik, $gorunen)
			);	
		}else{
			$id = DB::query(
				'UPDATE basliktar SET deger = deger + 1 WHERE ad = "'.$baslik.'"'
			);
		}

		$id = DB::insert(
			'INSERT INTO entry (metin,baslik,yazar,tarih) VALUES (?, ?, ?, ?)',
    		 array($metin, $baslik, $_SESSION['user'], $tarih)
		);
		// entry sayfasına yönlendirebilmesi için id'yi döndür 
		// bu id ajax sayfasından yakalanıyor
		return $id;
	}
}
?>