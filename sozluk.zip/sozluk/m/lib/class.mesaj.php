<?
class mesaj{
	
	function convert($d){
    	$bozuk = array("Ã¶","Ã¼","ÄŸ","Ã§","ÅŸ","Ä±","â€™","<script>","</script>");
    	$duzgun = array("ö","ü","ğ","ç","ş","ı","'"," "," ");
    	$sonuc = str_replace($bozuk,$duzgun,$d);
    	return $sonuc;
	}

	function konusma_kontrol($u1,$u2){
		$kontrol = DB::getVar('SELECT Count(id) FROM konusma WHERE u1 = ? and u2 = ?',array($u1,$u2));
		return $kontrol;
	}

	function konusma_listele($u1){
		$konusmalar = DB::get('SELECT * FROM konusma WHERE u1 = ?',array($u1));
		foreach ($konusmalar as $konusma) {
			$user = DB::getRow('SELECT * FROM user WHERE temiz = ?',array($konusma->u2));
			$online_kontrol = DB::getVar('SELECT Count(id) FROM online WHERE ad = ?',array($konusma->u2));
			if($online_kontrol>0){
				echo '<div class="konusma" data-konusma="'.$konusma->id.'"><img style="border:3px solid green;width:40px;height:40px;float:left" src="http://sozluksau.com/img/'.$user->img.'"><i style="float:left;margin-left:15px;margin-top:10px">'.self::convert($user->ad).'</i><i style="float:right;margin-top:10px;margin-right:15px"><font size="1">'.$konusma->st.'</font></i></div>';	
			}
			else{
				echo '<div class="konusma" data-konusma="'.$konusma->id.'"><img style="border:3px solid silver;width:40px;height:40px;float:left" src="http://sozluksau.com/img/'.$user->img.'"><i style="float:left;margin-left:15px;margin-top:10px">'.self::convert($user->ad).'</i><i style="float:right;margin-top:10px;margin-right:15px"><font size="1">'.$konusma->st.'</font></i></div>';
			}
		}
	}

	function mesaj_listele($id){
		$mesajlar = DB::get('SELECT * FROM msj WHERE knsm_id = ?',array($id));
		foreach ($mesajlar as $mesaj) {
			if($mesaj->u1==$_SESSION['user']){
				echo '<div class="left">'.$mesaj->msj.'</div><div style="clear:both"></div>';
			}else{
				echo '<div class="right">'.$mesaj->msj.'</div><div style="clear:both"></div>';
			}
		}
	}





}
?>