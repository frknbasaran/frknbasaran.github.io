<?
session_start();
include "sys/config.php";
include "lib/class.sozluk.php";
$sozluk = new sozluk;
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>test</title>
    <style type="text/css">
    #profil_ust{
        padding: 15px;
    }
    .entry_div{
        font-size: 13px;
        margin-top:10px;
        margin-right:10px;
        margin-left:10px;
        background-color: white;
        padding-left: 10px;
        padding-right: 10px;
        padding-top: 10px;
        padding-bottom: 20px;
        border-radius: 2px;

    }
    .entry_alt{
        margin-right:10px;
        margin-left:10px;
        margin-bottom: 10px;
        background-color: #f5f1ee;
        height: 40px;
    }
    </style>
	<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="css/jquery.mobile-1.4.0.min.css">
	<script src="js/jquery.js"></script>
	<script src="js/jquery.mobile-1.4.0.min.js"></script>
	<script type="text/javascript" src="js/system.js"></script>

</head>
<body>
<div data-role="page"  data-quicklinks="true">
<?
$sozluk->mobil_ust();
$sozluk->baslik_sirala();
?>
<div data-role="footer" data-position="fixed">
    <div data-role="navbar">
        <ul>
            <li><a href="#">bugün</a></li>
            <li><a href="#">dün</a></li>
            <li><a href="#">rastgele</a></li>
        </ul>
    </div><!-- /navbar -->
</div>
</div><!-- /page -->

<div data-role="page"  id="login">
	<div data-role="header" data-position="fixed" style="overflow:hidden;">
		<h1>giriş yap</h1>
    	<a data-rel="back" href="" data-rel="back" data-transition="flip" data-icon="carat-l" class="ui-btn-left">geri</a>
    	<a href="#register" data-transition="flip" data-icon="user" class="ui-btn-right">kaydol</a>
    </div>
	<div class="ui-grid-solo">
		<div class="ui-block-solo">
    		<h3>yazar girişi</h3>
		</div>
    	<div class="ui-block-solo">
    		<input type="text" id="mail" placeholder="e-posta">
		</div>
		<div class="ui-block-solo">
    		<input type="password" id="pass" placeholder="parola">
		</div>
		<div class="ui-block-solo">
    		<button id="login_but" class="ui-shadow ui-btn ui-corner-all">dal içeri</button>
		</div>
	</div>
</div>

<div data-role="page" data-transition="slideup" style="background-color:#EBEBEB" id="mesaj">
<div data-role="header"  style="overflow:hidden">
<h1>mesajlar</h1>
    <a href="#" data-rel="back" data-icon="carat-l" class="ui-btn-left">geri</a>
    <div data-role="navbar">
        <ul>
            <li><a  id="yeni_msj">yeni</a></li>
            <li><a  id="gelen"  href="#">gelen</a></li>
            <li><a  id="giden"  href="#">giden</a></li>
        </ul>
    </div><!-- /navbar -->
    <div id="mesaj_govde" style="overflow:y" class="ui-grid-solo">
    		<div class="ui-block-solo" id="mesaj_yaz">
				<div class="ui-block-a">yeni mesaj</div><div class="ui-block-a"><input type="text" id="kime" placeholder="kime"></div>
				<div class="ui-block-solo"><textarea rows="8" cols="30" name="textarea" id="mesaj_metin"></textarea></div>
    			<div class="ui-block-solo"><button id="login_but" class="ui-shadow ui-btn ui-corner-all">gönder</button></div>
    		</div>
    </div>
</div>
</div>

<div data-role="page" style="background-color:#EBEBEB" id="entry">
<div data-role="header" data-position="fixed">
<h1 id="entry_baslik">saü sözlük mobil</h1>
    <a href="#" data-rel="back" data-icon="carat-l" class="ui-btn-left">geri</a>
</div>
<div id="entryler"></div>
</div>

</body>
</html>

