<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="/css/reset.css">
    <link rel="stylesheet" href="/css/metro-bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    
    </script> 
    
        <?
        include 'sys/config.php';
        include "sys/ust.php";
        include "lib/class.sozluk.php";
        $sozluk = new sozluk;
        $ad = $_GET['ad'];
        $ad = DB::getVar('SELECT ad FROM user WHERE temiz = "'.$ad.'"');
        echo '<title>'.$sozluk->convert($ad).' - yazar profili</title>';
        ?>
    
</head>
<body class="metro">
<?php

?>
<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">bugün</a> <font color="silver" size="1"><? echo $sozluk->bugun();?></font><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
    <?
    $sozluk->baslik_sirala();
    ?>
</ul>
</div>
</div>
<div id="govde">
    <?

    $yazar = $sozluk->temizle($_GET['ad']);

    $row = DB::getRow('SELECT * FROM user WHERE temiz = "'.$yazar.'"');
    $best = DB::getRow('SELECT * FROM entry WHERE yazar = "'.$row->ad.'" and deleted = 0 ORDER BY puan DESC LIMIT 1');
    $goster = DB::getVar('SELECT goster FROM basliktar WHERE ad = "'.$best->baslik.'"');

    echo '
    <div id="profil">
    <img src="/img/'.$row->img.'" style="width:90px;height:90px" class="shadow"><span class="user"><strong>'.$sozluk->convert($row->ad).'</strong>';
    if($row->yetki=='mod'){
     echo '<br>jedi';   
    }else if($row->yetki=='admin'){
     echo '<br>sözlüğün ilk yazarı';
    }else{
        echo '<br>'.$row->nesil.' nesil '.$row->yetki;
    }
    echo '<br><br><p><em>"'.$row->ileti.'"</em></p></span><span style="margin-top:25px;margin-right:25px;float:right;cursor:pointer"><a style="color:black" href="../../mesajlar/'.$_GET['ad'].'">mesaj at</a></span><i style="float:right;margin-top:27px;margin-right:3px" class="icon-mail"></i><span style="margin-top:25px;margin-right:25px;float:right;cursor:pointer">'.$sozluk->entry_say($yazar).' entry</span><i style="float:right;margin-top:27px;margin-right:3px" class="icon-pencil"></i><span style="margin-top:25px;margin-right:25px;float:right;cursor:pointer">'.$sozluk->puan($yazar).' puan</span><i style="float:right;margin-top:27px;margin-right:3px" class="icon-clubs"></i>
    <div style="clear:both"></div>
    <br>
    <br>
    <blockquote>
    <p>'.$sozluk->convert($best->metin).'</p>
    <small>'.$sozluk->convert($goster).' <cite title="Source Title"></cite></small>
    </blockquote>
    <div style="clear:both"></div>
    ';
    $entries = DB::get('SELECT baslik,id FROM entry WHERE deleted = 0 and yazar = "'.$row->ad.'" ORDER BY id DESC LIMIT 25');
    $syc=0;
    echo '<div id="entriesL"><h3 style="margin-left:20px">son 10 entry</h3><ul>';
    foreach($entries as $entry){
      if($syc<10){
            $goster = DB::getVar('SELECT goster FROM basliktar WHERE ad = "'.$entry->baslik.'"');
            if(strlen($goster)>40){
                echo '<a href="../../entry/'.$entry->id.'/"><li><font size="2">'.substr($sozluk->convert($goster),0,40).'..</font></a>';    
            }else{
                echo '<a href="../../entry/'.$entry->id.'/"><li><font size="2">'.$sozluk->convert($goster).'</font></a>';
            }
        }
        $syc++;
    }
    echo '</ul></div>';
    $syc=0;
    $favs = DB::get('SELECT * FROM fav WHERE yazar = "'.$row->ad.'" ORDER BY id DESC LIMIT 10');
    echo '<div id="entriesR"><h3 style="margin-left:20px">yazarın favorileri</h3><ul>';
    foreach($favs as $fav){
      $baslik = DB::getVar('SELECT baslik FROM entry WHERE id = "'.$fav->entry.'"');
      $goster = DB::getVar('SELECT goster FROM basliktar WHERE ad = "'.$baslik.'"');
      if(strlen($goster)>40){
                echo '<a href="../../entry/'.$fav->entry.'/"><li><font size="2">'.substr($sozluk->convert($goster),0,40).'..</font></a>';    
            }else{
                echo '<a href="../../entry/'.$fav->entry.'/"><li><font size="2">'.$sozluk->convert($goster).'</font></a>';
            }
    }
    echo '</ul></div>';
    echo '<div style="clear:both"></div>';
    $goodVotes = DB::query('SELECT * FROM votes WHERE sahip = "'.$row->ad.'" and tur = "arti" ORDER BY id DESC LIMIT 10');
    echo '<div id="entriesL"><h3 style="margin-left:20px">son beğenilenleri</h3><ul>';
    foreach($goodVotes as $votes){
      $baslik = DB::getVar('SELECT baslik FROM entry WHERE id = "'.$votes->entry.'"');
      $goster = DB::getVar('SELECT goster FROM basliktar WHERE ad = "'.$baslik.'"');
      echo '<a href="../../entry/'.$votes->entry.'/"><li><font size="2">'.$sozluk->convert($goster).'</font></a>';
    }
    echo '</ul></div>';
    $goodVotes = DB::query('SELECT * FROM votes WHERE sahip = "'.$row->ad.'" and tur = "eksi" ORDER BY id DESC LIMIT 10');
    echo '<div id="entriesR"><h3 style="margin-left:20px">son eksilenenleri</h3><ul>';
    foreach($goodVotes as $votes){
      $baslik = DB::getVar('SELECT baslik FROM entry WHERE id = "'.$votes->entry.'"');
      $goster = DB::getVar('SELECT goster FROM basliktar WHERE ad = "'.$baslik.'"');
      echo '<a href="../../entry/'.$votes->entry.'/"><li><font size="2">'.$sozluk->convert($goster).'</font></a>';
    }
    echo '</ul></div>
    <div style="clear:both"></div>
    </div>';

    ?>
</div>

<script type="text/javascript" src="/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="/js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
    });
</script>
</body>
</html>
