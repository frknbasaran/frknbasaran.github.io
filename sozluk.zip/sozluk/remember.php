<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="/css/reset.css">
    <link rel="stylesheet" href="/css/metro-bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    <script src="/js/metro-accordion.js"></script>
    <script src="/js/metro-notify.js"></script>
    <title>parola hatırlatma - saü sözlük</title>
</head>
<body class="metro">
<?php
include 'sys/config.php';
include "sys/ust.php";
include "lib/class.sozluk.php";
$sozluk = new sozluk;
?>
<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">bugün</a> <font color="silver" size="1">568</font><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
    <?
    $sozluk->baslik_sirala();
    ?>
</ul>
</div>
</div>
<div id="govde">
    <?
    $topEntry = DB::getVar('SELECT Count(id) FROM entry');
    $topBaslik = DB::getVar('SELECT Count(id) FROM basliktar');
    $topYazar = DB::getVar('SELECT Count(id) FROM user WHERE yetki != "onaysiz" and yetki != "caylak"');
    $topCaylak = DB::getVar('SELECT Count(id) FROM user WHERE yetki = "caylak"');
    $topAktivasyonsuz = DB::getVar('SELECT Count(id) FROM user WHERE yetki = "onaysiz"');
    echo '
    <h2>parola hatırlatma servisi</h2>
    <p>kıyamam lan şifreni mi unuttun sen?</p>
    <div class="input-control text" style="width:230px;">
    <input id="mail" type="email" value="" placeholder="e-posta adresin"/></div>
    <br><button id="send_pass">yolla</button>
  ';
    
    
    ?>
</div>
<script type="text/javascript" src="/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="/js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
    });
</script>
</body>
</html>
