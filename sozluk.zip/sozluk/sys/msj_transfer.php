<?
include "sys/config.php";
include "lib/class.mesaj.php";

$mesaj = new mesaj;

if($_POST){
	
	switch($_POST['p']){
	
	case 'mesaj_gonder':
		$receiver = $mesaj->returnReceiverId($_POST['conv'],$_POST['me']);
		$mesaj->yeni_msj($_POST['conv'],$_POST['me'],$receiver,$_POST['msj']);
		break;
	


	}


}else{
	echo 'lan bi git';
}

?>