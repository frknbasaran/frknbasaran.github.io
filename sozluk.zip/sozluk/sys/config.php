<?php
/*
*
* Veritabanı bağlantısı için
* gerekli bağlantı bilgilerinin
* bulunduğu ayar dosyası.
*
*/
date_default_timezone_set('Europe/Istanbul');

define('MYSQL_HOST',	'localhost');
define('MYSQL_DB',		'sozluksa_demoDb');
define('MYSQL_USER',	'root');
define('MYSQL_PASS',	'N3OTezQDRM');
include 'db.php';
