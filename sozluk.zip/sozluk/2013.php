<?
session_start();
include "sys/config.php";
include "lib/class.sozluk.php";
$sozluk = new sozluk;
include "lib/class.chat.php";
$chat = new chat;
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/style.css">
	<script src="/js/jquery/jquery.min.js"></script>
<?
echo '<h3>2013 yılının istatistikleri</h3>';
echo '<h4>aylara göre entry dağılımı</h4>';
echo 'Mart:850<br>';
echo 'Nisan:967<br>';
echo 'Mayıs:1200<br>';
echo 'Haziran:1270<br>';
echo 'Temmuz:1061<br>';
$agustos = DB::getVar('SELECT Count(id) FROM entry WHERE tarih LIKE "%2013-08%"');
echo 'Ağustos: '.$agustos.'<br>';
$eylul = DB::getVar('SELECT Count(id) FROM entry WHERE tarih LIKE "%2013-09%"');
echo 'Eylül: '.$eylul.'<br>';
$ekim = DB::getVar('SELECT Count(id) FROM entry WHERE tarih LIKE "%2013-10%"');
echo 'Ekim: '.$ekim.'<br>';
$kasim = DB::getVar('SELECT Count(id) FROM entry WHERE tarih LIKE "%11.2013%"');
echo 'Kasım:'.$kasim.'<br>';
$aralik = DB::getVar('SELECT Count(id) FROM entry WHERE tarih LIKE "%12.2013%"');
echo 'Aralık:'.$aralik.'<br>';

echo '<h3>yılın en beğenilen entryleri</h3>';
$entryler = DB::get('SELECT * FROM entry WHERE yazar != "Ã¶te git deyuz" and yazar!= "kirmizibaslikliat" ORDER BY puan DESC LIMIT 10');
foreach ($entryler as $entry) {
	$baslik = DB::getVar('SELECT goster FROM basliktar WHERE ad = ?',array($entry->baslik));
	echo '<a style="color:black;text-decoration:underline;" href="../entry/'.$entry->id.'">'.$sozluk->convert($baslik).'/#'.$entry->id.'</a><b>@'.$sozluk->convert($entry->yazar).'</b><br>';
}



?>
</head>
<body>

</body>
</html>
