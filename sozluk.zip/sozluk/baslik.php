<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="/css/reset.css">
    <link rel="stylesheet" href="/css/metro-bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/tipsy.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    <script src="/js/metro-hint.js"></script>
    <script src="/js/metro-notify.js"></script>
    <script src="/js/jquery.tipsy.js"></script>
    
    </script> 
    <?
    include 'sys/config.php';
include "sys/ust.php";
include "lib/class.sozluk.php";
include "lib/class.online.php";
$online = new online;

$sozluk = new sozluk;
    $ad = $_GET['ad'];
    

    $gorunecek = DB::getVar('SELECT Count(id) FROM basliktar WHERE ad = "'.$ad.'"');
    if($gorunecek<1){
      echo '<title>'.$ad.' - saü sözlük</title>';
    }else{
      $goster = DB::getVar('SELECT goster FROM basliktar WHERE ad = "'.$ad.'"');
      echo '<title>'.$sozluk->convert($goster).' - saü sözlük</title>';
    }

    ?>
</head>
<body class="metro">

<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">#bugün</a> <font id="entry_sayi" color="silver" size="1"><? echo $sozluk->bugun();?></font><img id="loading" src="http://128.199.42.49/img/loading.gif" style="display:none;margin-right:15px;width:15px;height:15px;float:right"><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
  
    <?
    $online::main();
    $sozluk->baslik_sirala();
    ?>
</ul>
</div>
</div>
<div id="govde">
    
    <?
    if(isset($_GET['s'])){
      $syf = $_GET['s'];
    }else{
      $syf = 1;
    }
    $sozluk->entry_getir($_GET['ad'],$syf);
    $sozluk->entry_giris_alani();
    ?>

<div style="clear:both"></div>
<div id="footer"></div>
</div>

</div>

<script type="text/javascript" src="/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="/js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
      $('.yildizli').tipsy({gravity:'s'});
    });

</script>
</body>
</html>
