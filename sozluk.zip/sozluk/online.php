<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="/css/reset.css">
    <link rel="stylesheet" href="/css/metro-bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/tipsy.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    <script src="/js/metro-hint.js"></script>
    <script src="/js/metro-notify.js"></script>
    <script src="/js/jquery.tipsy.js"></script>
    <title>online yazarlar - saü sözlük</title>
    <?
    include 'sys/config.php';
include "sys/ust.php";
include "lib/class.sozluk.php";
include "lib/class.online.php";
$online = new online;
$online::main();
  



$sozluk = new sozluk;


    ?>
</head>
<body class="metro">
<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">#bugün</a> <font id="entry_sayi" color="silver" size="1"><? echo $sozluk->bugun();?></font><img id="loading" src="http://developing.sozluksau.com/img/loading.gif" style="display:none;margin-right:15px;width:15px;height:15px;float:right"><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
    <?
    $sozluk->baslik_sirala();
    
    ?>
</ul>
</div>
</div>
<div id="govde">

<div style="clear:both"></div>

    <?
    if(isset($_SESSION['user'])){
      $online::online_listele();
    }else{
      echo '<h2>hoop! önce giriş yapman lazım</h2>';
    }
    
    ?>


<div style="clear:both"></div>
<div id="footer"><center><a href="mailto:iletisim@sozluksau.com">iletişim</a><a href="../../hakkinda">hakkında</a> <a href="../../baslik/ssk/">kurallar</a> <a target="_new" href="http://facebook.com/sausozluk">facebook</a><a target="_new" href="http://twitter.com/sozluksau">twitter</a> <a href="">google+</a></center></div>
</div>

</div>

<script type="text/javascript" src="/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="/js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
      $('.yildizli').tipsy({gravity:'s'});
    });

</script>
</body>
</html>
