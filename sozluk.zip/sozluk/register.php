<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="/css/reset.css">
    <link rel="stylesheet" href="/css/metro-bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    <script src="/js/metro-accordion.js"></script>
    <script src="/js/metro-notify.js"></script>
    <title>kaydol - saü sözlük</title>
</head>
<body class="metro">
<?php
include 'sys/config.php';
include "sys/ust.php";
include "lib/class.sozluk.php";
$sozluk = new sozluk;
?>
<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">bugün</a> <font color="silver" size="1">568</font><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
    <?
    $sozluk->baslik_sirala();
    ?>
</ul>
</div>
</div>
<div id="govde">
    <?
    $topEntry = DB::getVar('SELECT Count(id) FROM entry');
    $topBaslik = DB::getVar('SELECT Count(id) FROM basliktar');
    $topYazar = DB::getVar('SELECT Count(id) FROM user WHERE yetki != "onaysiz" and yetki != "caylak"');
    $topCaylak = DB::getVar('SELECT Count(id) FROM user WHERE yetki = "caylak"');
    $topAktivasyonsuz = DB::getVar('SELECT Count(id) FROM user WHERE yetki = "onaysiz"');
    $durum = DB::getVar('SELECT durum FROM durum WHERE id = ?',array('1'));
    if($durum=='1'){
        echo '
    <div class="login">
    <h2>yazar ol</h2>
    <p><em><small>saü sözlükte yazar olmak için doğru bilgileri gir, gelen e-postaya tıkla ve yazmaya başla.<br> bir süre çaylak olarak takılacaksın moderatörlerimiz<br>
    en kısa sürede entry profilini değerlendirecektir.</em></small></p><br>
    <div class="input-control text" style="width:230px;">
    <input type="text" id="nick" value="" placeholder="nick"/>
    </div>
    <br>
    <div class="input-control text" style="width:230px;">
    <input id="mail" type="email" value="" placeholder="e-posta adresin"/></div>
    <br>
    <div class="input-control text" style="width:230px;">
    <input id="pass" type="password" value="" placeholder="parolanı gir"/>
    <button class="btn-reveal"></button></div><br>
    <div style="width:230px;" class="input-control password">
    <input id="verify_pass" type="password" value="" placeholder="parolayı tekrar onayla"/>
    <button class="btn-reveal"></button></div><br>
    <div class="input-control text" style="width:230px;">
    <input id="dtarihi" type="date" value="" placeholder="doğum tarihi"/></div>
    <br><div class="input-control select"><select style="width:230px" id="cins">
    <option value="e">erkek</option><option value="k">kadın</option><option = "g">ben de saklı</option>
    </select></div>
    <div class="input-control">
    <button id="kaydol">beni de alın</button>
    </div>
    </div>
  ';
    }else{
        echo '<h2>üzgünüz</h2><br>yazar alımı yönetim tarafından bi süreliğine kapatılmış.';
    }
    
    
    ?>
</div>
<script type="text/javascript" src="/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="/js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
    });
</script>
</body>
</html>
