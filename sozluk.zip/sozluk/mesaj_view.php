<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="/css/reset.css">
    <link rel="stylesheet" href="/css/metro-bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    <script src="/js/metro-accordion.js"></script>
    <script src="/js/metro-notify.js"></script>
    <script src="/js/metro-tab-control.js"></script>
    <script type="text/javascript">
    $(document).ready(function(){


        $('body').on('keypress','#yeni_mesaj',function(e){
            var state = 0;
            if(e.which == 13) {
                state = 1;
            }
            if(state==1){
                var me = $(this).attr('data-sender');
                var conv = $(this).attr('data-conv');
                var mesaj = $('#yeni_mesaj').val();
                $.post('http://sozluksau.com/ajax',{process:'mesaj_gonder',conv:conv,msj:mesaj,me:me},function(d){
                    $('#mesaj_cerceve').append('<div class="sag_mesaj">'+mesaj+'</div><div style="clear:both"></div>');
                    var height = $('#mesaj_cerceve')[0].scrollHeight;
                    $('#mesaj_cerceve').scrollTop(height);
                });
                $('#yeni_mesaj').val('');
            }

        });

        $('.konusma_sil').click(function(){
            var konusma = $(this).attr('data-conv');
            $.post('http://sozluksau.com/ajax',{process:'konusma_sil',me:me,conv:konusma},function(e){
                $.Notify({content:'konuşmanın sendeki kopyası silindi'});
            });
        });

    });
    </script>
    <title>mesajlar - sozluksau.com</title>
</head>
<body class="metro">
<?php
include 'sys/config.php';
include "sys/ust.php";
include "lib/class.mesaj.php";
$mesaj = new Mesaj;
include "lib/class.sozluk.php";
$sozluk = new sozluk;
?>
<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">bugün</a> <font color="silver" size="1"><? echo $sozluk->bugun();?></font><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
    <?
    $sozluk->baslik_sirala();
    ?>
</ul>
</div>
</div>
<div id="govde">
        <?
        if(isset($_SESSION['user'])){
            $konusma = intval($_GET['konusma']);
            
            $me = $mesaj->getIdByName($_SESSION['user']);
            if($mesaj->guvenlikKontrol($konusma,$me)){
                $other = $mesaj->returnOther($konusma,$me);
                $userData = db::getRow('SELECT * FROM user WHERE id = ?',array($other));
                echo '<div style="width:60%;" id="mesaj_ust"><img style="width:40px;height:40px;margin:10px" src="http://sozluksau.com/img/'.$userData->img.'"><strong>'.$sozluk->convert($userData->ad).'</strong><span data-conv="'.$konusma.'" class="konusma_sil icon-history" style="float:right;margin-top:20px;cursor:pointer"><font face="Verdana"> konuşma geçmişini sil</font></span></div>';
                echo '<div id="mesaj_cerceve">';
                $mesaj->mesajSirala($konusma,$me);
                echo '</div><textarea rows="1" data-sender="'.$me.'" data-conv="'.$konusma.'" id="yeni_mesaj"></textarea>';
                $mesaj->okundu($konusma);
            }else{
                echo '<script>window.location="http://gotegirensemsiyeacildi.net";</script>';
            }

            

        }else{
            echo '<h2> :( olmadı yar</h2>
            <p> bu sayfayı görebilmek için önce sağ üstten giriş yapman lazım</p>';
        }
        ?>
</div>

<script type="text/javascript" src="/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="/js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
    });
</script>
</body>
</html>
