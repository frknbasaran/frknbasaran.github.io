$('body').on('keypress','#metin',function(e){
         if(e.which == 13) {
            alert('enter detected');
         }
});