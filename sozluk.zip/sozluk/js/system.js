$(document).ready(function(){
      // giriş formu getir
       $('body').on('click', '#login', function(){
      $('#govde').empty();
      $('#govde').append('<div class="login"><h2>yazar girişi</h2><p><em><small>üniversitenin bu karanlık ve puslu sözlüğünde yazılanlar, kurumlar ve kişiler tamamen hayal ürünüdür.</em></small></p><br><div class="input-control text" style="width:230px;"><input type="email" tabindex="1001" id="mail" value="" placeholder="nick değil e-posta"/><button class="btn-clear"></button></div><br><div style="width:230px;" class="input-control password"><input tabindex="1002" type="password" id="pass" value="" placeholder="çok gizli parolan"/><button class="btn-reveal"></button></div><div class="input-control"><input type="submit" id="login_submit" tabindex="1003" value="dal içeri"/></div><br><h3>sıkıntı yok hafız</h3><a href="../../unutkan">parolanı mı unuttun?</a><br><a id="register">yazar değil misin?</a></div>');
     });
       // yazar kayıt formu getir
     $('body').on('click','#register',function(){
      window.location="../../kaydol";
      
     });
       // başlık arama çubuğu komutları
      $('body').on('keypress','#ara',function(e){
         if(e.which == 13) {
            var baslik = $(this).val();
            var newchar = ' ';
            baslik = baslik.split('<').join(newchar);
            baslik = baslik.split('>').join(newchar);
            baslik = baslik.split('/').join(newchar);
            baslik = baslik.split('?').join(newchar);
            baslik = baslik.split("'").join(newchar);
            baslik = baslik.split('"').join(newchar);
            baslik = baslik.split('^').join(newchar);
            baslik = baslik.split('.').join(newchar);
            baslik = baslik.split(':').join(newchar);
            baslik = baslik.split(';').join(newchar);
            

            baslik = baslik.trim();
            $(location).attr('href', '../../baslik/'+baslik+'/');
         }
      });

      $('.konusma').click(function(){
        var id = $(this).attr('data-konusma');
        $.Notify({content:id});
      });

      $('.mod_yap').click(function(){
        var id = $(this).attr('id');
        $.post('http://128.199.42.49/ajax',{process:'mod_yap',id:id},function(e){
          $.Notify({content:e});
        });
      });

       $('.onayla').click(function(){
        var id = $(this).attr('id');
        $.post('http://128.199.42.49/ajax',{process:'onayla',id:id},function(e){
          $.Notify({content:e});
        });
      });

      $('.caylak_yap').click(function(){
        var id = $(this).attr('id');
        $.post('http://128.199.42.49/ajax',{process:'caylak_yap',id:id},function(e){
          $.Notify({content:e});
        });
      });

      $('.yazar_ucur').click(function(){
        var id = $(this).attr('id');
        $.post('http://128.199.42.49/ajax',{process:'ucur',id:id},function(e){
          $.Notify({content:e});
        });
      });
        
        $('body').on('click','.dun',function(){
          $('#loading').css('display','block');
          $('.bugun:last').empty();
          $('#entry_sayi').empty();
            $('.bugun:last').append('#dün');
          $.post('http://128.199.42.49/ajax',{process:'dun'},function(e){
           $('#baslik_listesi').empty();
            $('#baslik_listesi').append(e);
            $('#loading').css('display','none');
          });
          $.post('http://128.199.42.49/ajax',{process:'dunsay'},function(e){
            $('#entry_sayi').empty();
          });
        });

        // mail kontrol fonksiyonu
        function MailKontrol(email)
        {
          var kontrol = new RegExp(/^[^0-9][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[@][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{2,4}$/i);
          return kontrol.test(email);
        }

        // login denetimleri
        $('body').on('keypress','#mail,#pass',function(e){
         if(e.which == 13) {
            var mail = $('#mail').val();
            var pass = $('#pass').val();
            if(mail=='' || pass==''){ 
              $.Notify({ content: 'tüm alanları doldur müdür' });  
            }else{
              
              if(MailKontrol(mail)){
                // ajax aracılığıyla login işlemi
                $.post('http://128.199.42.49/ajax',{process:'login',mail:mail,pass:pass},function(e){
                     
                     if(e==1) window.location="";  
                     else $.Notify({ content: 'bilgilerini kontrol et' });  
                
                });
              }else{
                $.Notify({ content: 'geçerli bir e-posta gir' });  
              }
            }
         }
        });
    
        $('body').on('click', '#baslikUpdate', function() {
            var title = $('#baslik').val();
            $.post('http://128.199.42.49/ajax', {process:'title', title:title}, function(e) {
                if(e==1) alert("başlık güncellendi");
                else alert("hata var tekrar dene");
            });
        });
    
        $('body').on('click', '#googleUpdate', function() {
            var seo = $('#google').val();
            $.post('http://128.199.42.49/ajax', {process:'google', google:seo}, function(e) {
                if(e==1) alert("google açıklaması güncellendi");
                else alert("hata var tekrar dene");
            });
        });

        // login butonu icin denetimler
        $('body').on('click','#login_submit',function(){
           var mail = $('#mail').val();
            var pass = $('#pass').val();
            if(mail=='' || pass==''){ 
              $.Notify({ content: 'tüm alanları doldur müdür' });  
            }else{
              
              if(MailKontrol(mail)){
                // ajax aracılığıyla login işlemi
                $.post('http://128.199.42.49/ajax',{process:'login',mail:mail,pass:pass},function(e){
                     
                     if(e==1) window.location="";  
                     else $.Notify({ content: 'bilgilerini kontrol et' });  
                
                });
              }else{
                $.Notify({ content: 'geçerli bir e-posta gir' });  
              }
            }
          });

        $('body').on('click','#logoff',function(){
          $.post('http://128.199.42.49/ajax',{process:'logoff'},function(e){
            if(e==1) window.location="";
          });
        });

        // yazar üstü divi
        $('.yazar').mouseenter(function(){
          var entry = $(this).attr('data-entry');
          var yazar = $(this).attr('id');
          var ad = $(this).html();
          if(ad.length()>15)
          ad = ad.substr(0,10);
          $('.yazar_bio').remove();
          $('#'+entry).before('<div class="yazar_bio" id="'+yazar+'"><img src="/img/pic.jpg" style="width:40px;height:40px" class="shadow"><b>'+ad+'</b><br><font size="1">birinci nesil yazar</font></div>');
        });
        
        // yazar üstü divi kapat
        $('.yazar').mouseleave(function(){
          var entry = $(this).attr('data-entry');
          var yazar = $(this).attr('id');
          $('.yazar_bio').remove();
        });
        //yildizli bkz baloncuğu

        //** entry butonları **//
        //bkz 
        $('#bkz').click(function(){
          var baslik = prompt("bakınız verilecek başlık nedir?");
          var entry = $('#entry').val();
          $('#entry').val(entry + "[bkz:"+baslik+"]");
        });
        //yıldızlı
        $('#yildiz').click(function(){
          var baslik = prompt("bakınız verilecek başlık nedir?");
          var entry = $('#entry').val();
          $('#entry').val(entry + "[*:"+baslik+"]");
        });

        $('#link').click(function(){
          var baslik = prompt("url yi gir:");
          var gorunecek = prompt("entry de nasıl görünsün?");
          var entry = $('#entry').val();
          $('#entry').val(entry + "[b:"+baslik+":"+gorunecek+"]");
        });
        
        //spoiler
        $('#spoiler').click(function(){
          var entry = $('#entry').val();
          var spoiler = prompt("spoilerın içini doldur");
          $('#entry').val(entry + "----spoiler----\n\n"+spoiler+"\n\n----spoiler----");
        });
        
        //entry girme fonksiyonu
        $('#send_entry').click(function(){
          var metin = $('#entry').val();
          var sayi = metin.length;
          if(sayi<10){
            $.Notify({ content: 'bamya entry detected' }); 
          }else{
            var baslik = $(this).attr('data-baslik');
            $.post('http://128.199.42.49/ajax',{process:'ekleEntry',metin:metin,baslik:baslik},function(e){
              if(e!='0' && e!='1'){
              window.location="../../entry/"+e;  
            }else if(e=='0'){
              $.Notify({content:'tekrar oturum aç müdür'});
            }else if(e=='1'){
              $.Notify({content:'çaylaklar başlık açamaz'});
            }
              
            });  
          }
        });

        //adm process

        //başlık silme
        $('.baslik_sil').click(function(){
          var baslik = $(this).attr("data-ad");
          if(confirm('başlığa demokrasi getirmek üzeresin, onaylıyor musun?'))
          $.post('http://128.199.42.49/ajax',{process:'baslik_sil',baslik:baslik},function(e){
            if(e=='1') $.Notify({content:'başlık silindi'});
            else if(e=='2') $.Notify({content:'başlık silinmedi bi terslik var'});
            else $.Notify({content:'burayı terk et'});
          });
          else $.Notify({content:'silme işlemi iptal edildi'});
        });

        // başlık adı düzenle
        $('.baslik_duzenle').click(function(){
          var baslik = $(this).attr('data-ad');
          var yeni = prompt("başlığın kulağına ezanı okuduk hadi sen de ismini fısılda");
          $.post('http://128.199.42.49/ajax',{process:'baslik_duzenle',baslik:baslik,yeni:yeni},function(e){
            if(e=='0') $.Notify({content:'burayı terk et'});
            else window.location="../../baslik/"+e+"/"; 
          });
        });

        //entry buttons process

        $('.entry_arti').click(function(){
          var id = $(this).attr('id');
          $.post('http://128.199.42.49/ajax',{process:'arti',id:id},function(e){
            $.Notify({content:e});
          });
        });

        $('#duyuru_gonder').click(function(){
          var baslik = $('#baslik').val();
          var duyuru = $('#duyuru').val();
          $.post('http://128.199.42.49/ajax',{process:'duyur',baslik:baslik,duyuru:duyuru},function(e){
            $.Notify({content:e});
          });
        });

        $('.entry_eksi').click(function(){
          var id = $(this).attr('id');
          $.post('http://128.199.42.49/ajax',{process:'eksi',id:id},function(e){
            $.Notify({content:e});
          });
        });

        $('.entry_sikayet').click(function(){
          var id = $(this).attr('id');
          window.location="../../sikayet/"+id;
        });

        $('.entry_fav').click(function(){
          var id = $(this).attr('id');
          $.post('http://128.199.42.49/ajax',{process:'fav',id:id},function(e){
            $.Notify({content:e});
          });
        });

        $('.entry_duzenle').click(function(){
          var id = $(this).attr('id');
          window.location="../../duzenle/"+id;
        });

        $('.entry_sil').click(function(){
          if(confirm("bu giriye demokrasi getirmek üzeresin, devam etmek istiyor musun?")){
            var id = $(this).attr('id');
            var durum=0;
            $.post('http://128.199.42.49/ajax',{process:'entry_sil',id:id},function(e){
              if(e=='1'){
                $('#'+id).fadeOut();
                $('.'+id).fadeOut();
              }else{
              $.Notify({content:'burayı terk et'});
            }
          });  
          }else{
            $.Notify({content:'silme işlemi iptal edildi'});
          }
        });
        $('#nesilUpdate').click(function(){
            var deger = $('#nesil').val();
            $.post('http://128.199.42.49/ajax',{process:'nesilUpdate',nesil:deger},function(e){
                if(e=='1'){
                    $.Notify('nesil ayarları güncellendi');
                }else{
                    $.Notify('bi hata var sonra dene');
                }
            });
        });
        
         $('#yazarAlimi').change(function(){
            var deger = $(this).val();
            $.post('http://128.199.42.49/ajax',{process:'durumUpdate',durum:deger},function(){
                if(e=='1'){
                    $.Notify('yazar alım ayarları güncellendi');
                }else{
                    $.Notify('bi hata var sonra dene');
                }
            });
        });
    
        $('.entry_paylas').click(function(){
          var id = $(this).attr('id');
          window.location="../../entry/"+id;
        });

        $('#sikayet_et').click(function(){
          var id = $(this).attr('class');
          var sikayet = $('#sikayet').val();
          $.post('http://128.199.42.49/ajax',{process:'sikayet',sikayet:sikayet,id:id},function(e){
            if(e=='1'){$.Notify({content:'şikayetiniz rus istihbaratına iletildi'}); window.location="../../entry/"+id;}
            else $.Notify({content:'bişeyler ters gitti'});
          });
        });

        $('#edit_entry').click(function(){
          var metin = $('#entry').val();
          var id = $(this).attr('data-entry');
          var sayi = metin.length;
          if(sayi<15){
            $.Notify({ content: 'bamya entry dedected' }); 
          }else{
            $.post('http://128.199.42.49/ajax',{process:'editEntry',metin:metin,id:id},function(e){
              window.location="../../entry/"+e;
            });  
          }
        });

        $('#gonder_mesaj').click(function(){
          var to = $('#kime').val();
          var msj = $('#mesaj').val();
          $.post('http://128.199.42.49/ajax',{process:'message_send',to:to,msj:msj},function(e){
            $.Notify({content:e});
          });
        });

        $('.icon-remove').click(function(){
          var id = $(this).attr('id');
          $.post('http://128.199.42.49/ajax',{process:'del_mesaj',id:id},function(e){
            $('#'+id).parent().parent().remove();
            $.Notify({content:e});
          });
        });

        $('.entry_mesaj').click(function(){
          var to = $(this).attr('id');
          $.post('http://128.199.42.49/ajax',{process:'entrydenMesaj',to:to},function(e){
            window.location="../../mesajlar/"+e;
          });
        });

        $('#change_ileti').click(function(){
          var ileti = $('#ileti').val();
          var newchar = ' ';
            ileti = ileti.split('<').join(newchar);
            ileti = ileti.split('>').join(newchar);
            ileti = ileti.split('/').join(newchar);
            ileti = ileti.split('?').join(newchar);
            ileti = ileti.split("'").join(newchar);
            ileti = ileti.split('"').join(newchar);
            ileti = ileti.split('^').join(newchar);
            ileti = ileti.split('.').join(newchar);
            ileti = ileti.split(':').join(newchar);
            ileti = ileti.split(';').join(newchar);
            ileti = ileti.trim();
          $.post('http://128.199.42.49/ajax',{process:'iletidegistir',ileti:ileti},function(e){
            $.Notify({content:e});
          });
        });

        $('#change_pass').click(function(){
          var old = $('#old_pass').val();
          var new_pass = $('#new_pass').val();
          var verify_new_pass = $('#verify_new_pass').val();
          if(new_pass == verify_new_pass){
            $.post('http://128.199.42.49/ajax',{process:'change_pass',old:old,yeni:new_pass},function(e){
              $.Notify({content:e});
            });
          }
          else{
            $.Notify({content:'yeni parolalar eşleşmedi'});
          }
        });

        $('#change_mail').click(function(){
          var yeni = $('#new_mail').val();
          var pass = $('#pass').val();
          var verify_pass = $('#pass_verify').val();
          if(pass == verify_pass){
            $.post('http://128.199.42.49/ajax',{process:'change_mail',yeni:yeni,pass:pass},function(e){
              $.Notify({content:e});
            });
          }
          else{
            $.Notify({content:'parolalar eşleşmedi'});
          }
        });

        $('#kaydol').click(function(){
          var nick = $('#nick').val();
          var pass = $('#pass').val();
          var pass_verify = $('#verify_pass').val();
          var mail = $('#mail').val();
          var dtarihi = $('#dtarihi').val();
          var cins = $('#cins').val();
          if(nick!='' && pass!='' && pass_verify != '' && mail != '' && dtarihi != '' && cins != ''){
            if(MailKontrol(mail)){
            if(pass==pass_verify){
              $.post('http://128.199.42.49/ajax',{process:'register',nick:nick,mail:mail,pass:pass,cins:cins,dtarihi:dtarihi},function(e){
                if(e=='1'){
                  window.location="../../hosgeldin";
                }else{
                  $.Notify({content:e});
                }
              });
            }
            else{
              $.Notify({content:'parolalar eşleşmedi'});
            }
          }
          else{
            $.Notify({content:'geçersiz e-posta.'});
          }
        }else{
          $.Notify({content:'tüm alanları doldur'});
        }
          
        });

        $('#send_pass').click(function(){
          var mail = $('#mail').val();
          if(MailKontrol(mail)){
            $.post('http://128.199.42.49/ajax',{mail:mail,process:'remember_pass'},function(e){
              $.Notify({content:e});
            });
          }else{  
            $.Notify({content:'geçersiz e-posta'});
          }
        });

        $('.sayfa').change(function(){
          var baslik = $(this).attr('data-syf');
          var sayfa = $(this).val();
          window.location="../../baslik/"+baslik+"/"+sayfa;
        });

        $('body').on('click','.baslik_ekle',function(){

          var sayac = $(this).attr('data-bslk');
          $(this).empty();
          $(this).append('<img style="width:15px;height:15px;margin-left:80px" src="http://sozluksau.com/img/loading.gif">');
          $.post('http://128.199.42.49/ajax',{syc:sayac,process:'baslik_ekle'},function(e){
            $('#baslik_listesi').append(e);
            $( ".baslik_ekle" ).first().remove();
          });

        });

        $('.bugun').click(function(){
          $('#loading').css('display','block');
          $('.bugun:last').empty();
          $('#entry_sayi').empty();
          $('.bugun:last').append('#bugün');
          $.post('http://128.199.42.49/ajax',{process:'bugun'},function(e){
            $('#baslik_listesi').empty();
            $('#baslik_listesi').append(e);
            $('#loading').css('display','none');
            

          });
        });

        $('.random').click(function(){
          $('#loading').css('display','block');
          $('.bugun:last').empty().append('#rastgele');
          $('#entry_sayi').empty();
          $.post('http://128.199.42.49/ajax',{process:'random'},function(e){
            $('#baslik_listesi').empty();
            $('#baslik_listesi').append(e);
            $('#loading').css('display','none');

          });
        });

        $('body').on('keypress','#ara',function(e){
          if(e.which==32){
            var key = $(this).val();
            $('#loading').css('display','block');
            $.post('http://128.199.42.49/ajax',{process:'ara',key:key},function(e){
              $('#baslik_listesi').empty();
            $('#baslik_listesi').append(e);
            $('#loading').css('display','none');
            });
          }
        });

        
        
});