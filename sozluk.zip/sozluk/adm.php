<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="/css/reset.css">
    <link rel="stylesheet" href="/css/metro-bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    <script src="/js/metro-accordion.js"></script>
    <script src="/js/metro-notify.js"></script>
    <script src="/js/metro-tab-control.js"></script>
    <title>yönetim - sozluksau.com</title>
</head>
<body class="metro">
<?php
include 'sys/config.php';
include "sys/ust.php";
include "lib/class.sozluk.php";
$sozluk = new sozluk;
?>
<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">#bugün</a> <font color="silver" size="1"><? echo $sozluk->bugun();?></font><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
    <?
    $sozluk->baslik_sirala();
    ?>
</ul>
</div>
</div>
<div id="govde">
        <?
        if(isset($_SESSION['user'])){
            if($_SESSION['yetki']=='admin' || $_SESSION['yetki']=='mod'){
                echo '
                <h2>yönetim paneli</h2>
                <div class="tab-control" data-effect="fade[slide]" data-role="tab-control">
                    <ul class="tabs">
                        <li class="active"><a href="#_page_1">yazarlar</a></li>
                        <li><a href="#_page_2">çaylaklar</a></li>
                        <li><a href="#_page_3">yasaklılar</a></li>
                        <li><a href="#_page_4">şikayet</a></li>
                        <li><a href="#_page_5">ayarlar</a></li>
                    </ul>
 
                    <div class="frames">
                        <div class="frame" id="_page_1">
                        <h3>yazarlar</h3>
                        <ul>
                        ';
                        $yazarlar = DB::get('SELECT * FROM user WHERE yetki = "yazar" or yetki = "mod" or yetki = "admin" ORDER BY id DESC');
                        foreach ($yazarlar as $yazar) {
                            if($_SESSION['yetki']=='admin')
                            echo '<li style="margin-bottom:3px"><span><img src="img/'.$yazar->img.'" style="width:40px;height:40px;margin-right:15px"></span><span><a href="../../yazar/'.$yazar->temiz.'/">'.$sozluk->convert($yazar->ad).'</a></strong><i style="margin-left:5px">'.$yazar->mail.'</i></span><span style="float:right"><i id="'.$yazar->id.'" style="margin-right:5px" class="icon-user-3 mod_yap"><strong>mod yap</strong></i><i id="'.$yazar->id.'" style="margin-right:5px" class="icon-tux caylak_yap"><strong> çaylak yap</strong></i><i id="'.$yazar->id.'" style="margin-right:5px" class="icon-cancel-2 yazar_ucur"><strong> uçur</strong></i></span></li>';
                            else echo '<li style="margin-bottom:3px"><span><img src="img/'.$yazar->img.'" style="width:40px;height:40px;margin-right:15px"></span><span><a href="../../yazar/'.$yazar->temiz.'/">'.$sozluk->convert($yazar->ad).'</a></strong><i style="margin-left:5px">'.$yazar->mail.'</i></span><span style="float:right"><i id="'.$yazar->id.'" style="margin-right:5px" class="icon-tux caylak_yap"><strong> çaylak yap</strong></i><i id="'.$yazar->id.'" style="margin-right:5px" class="icon-cancel-2 yazar_ucur"><strong> uçur</strong></i></span></li>';
                        }
                        echo '</ul>';
                        echo '
                        </div>
                        <div class="frame" id="_page_2">
                        <h3>onay bekleyen çaylaklar</h3>
                        <ul>
                        ';
                        $caylaklar = DB::get('SELECT * FROM user WHERE yetki = "caylak" or yetki = "onaysiz" ORDER BY id DESC');
                        foreach ($caylaklar as $caylak) {
                            $entry = DB::getVar('SELECT Count(id) FROM entry WHERE yazar = ?',array($caylak->ad));
                            echo '<li style="margin-bottom:3px"><span><img src="img/'.$caylak->img.'" style="width:40px;height:40px;margin-right:15px"></span><span><a href="../../yazar/'.$caylak->temiz.'/">'.$sozluk->convert($caylak->ad).'</a></strong></span><span>'.$entry.' entry girmiş</span><span style="float:right"><i id="'.$caylak->id.'" style="margin-right:5px" class="icon-tux onayla"><strong> onayla</strong></i><i id="'.$caylak->id.'" style="margin-right:5px" class="icon-cancel-2 yazar_ucur"><strong> uçur</strong></i></span></li>';
                        }
                        echo '</ul>';

                        echo '
                        </div>
                        <div class="frame" id="_page_3">
                        <h3>yasaklılar</h3>
                        <ul>
                        ';
                        $yasaklilar = DB::get('SELECT * FROM user WHERE yetki = "silik" ORDER BY id DESC');
                        foreach ($yasaklilar as $yasakli) {
                            echo '<li style="margin-bottom:3px"><span><img src="img/'.$yasakli->img.'" style="width:40px;height:40px;margin-right:15px"></span><span><a href="../../yazar/'.$yasakli->temiz.'/">'.$sozluk->convert($yasakli->ad).'</a></strong></span><span style="float:right"><i id="'.$yasakli->id.'" style="margin-right:5px" class="icon-tux onayla"><strong> affet bağrına bas</strong></i></span></li>';
                        }
                        echo '</ul>';
                        echo '
                        </div>
                        <div class="frame" id="_page_4">
                        <h3>şikayetler</h3>
                        <ul>
                        ';
                        $sikayetler = DB::get('SELECT * FROM sikayet ORDER BY id DESC');
                        foreach ($sikayetler as $sikayet) {
                            $user = DB::getRow('SELECT * FROM user WHERE ad = "'.$sikayet->user.'"');
                            echo '<li style="margin-bottom:3px"><span><img src="img/'.$user->img.'" style="width:40px;height:40px;margin-right:15px"><strong>'.$sikayet->user.'</strong></span><span style="float:right">'.$sozluk->convert($sikayet->neden).'</span><span style="float:right"><i id="'.$sikayet->entry.'" style="margin-right:5px"><a href="../../entry/'.$sikayet->entry.'/">#'.$sikayet->entry.'</a></i></span></li>';
                        }
                echo '</ul>
                        </div>';
                
                    $nesil = DB::getRow('SELECT * FROM nesil WHERE id = ?',array('1'));
                
                
                echo '<div class="frame" id="_page_5">
                            <h3>nesil belirle</h3>
                            <input type="text" id="nesil" value="'.$nesil->nesil.'"> <button id="nesilUpdate">değiştir</button>
                            <p>varsayılan olarak birinci nesil yazar, nesil isimlerinde turkce karakter kullanma</p>
                            <h3>yazar alımını ayarları</h3>
                            <select id="yazarAlimi">';
                
                    $durum = DB::getRow('SELECT * FROM durum WHERE id = ?',array('1'));
                    if($durum->durum==1){
                    echo '<option value="1" selected>Açık</option><option value="0">Kapalı</option>';
                    }else{
                    echo '<option value="1">Açık</option><option value="0" selected>Kapalı</option>';
                    }
                    echo '</select>';
                    
                $degerler = DB::getRow('SELECT * FROM durum WHERE id = ?', array(1));
                
                    echo '<h3>sözlük başlığı</h3>
                        <input type="text" id="baslik" value="'.$degerler->title.'"> <button id="baslikUpdate">değiştir</button>
                        <p>sözlüğün sol üstünde yazan başlıktır</p>';
                
                    echo '<h3>google açıklaması</h3>
                        <textarea row="3" col="50" id="google">'.$degerler->seo.'</textarea> <button id="googleUpdate">değiştir</button>
                        <p>google sonucunda sitenin açıklamasında yazacak olan metin, 100 karakteri geçmesi önerilmez.</p>';
                    
                           
                                
                            echo '
                       </div>
                    </div>
                </div>

                ';
            }else{
                echo '<h2>git burdan</h2>
            <p> bu sayfayı göremezsin</p>';    
            }
        }else{
            echo '<h2> :( olmadı yar</h2>
            <p> bu sayfayı görebilmek için önce sağ üstten giriş yapman lazım</p>';
        }
        ?>
</div>

<script type="text/javascript" src="/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="/js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
    });
</script>
</body>
</html>
