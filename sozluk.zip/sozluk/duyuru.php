<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="/css/reset.css">
    <link rel="stylesheet" href="/css/metro-bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    <script src="/js/metro-accordion.js"></script>
    <title>duyurular - saü sözlük</title>
</head>
<body class="metro">
<?php
include 'sys/config.php';
include "sys/ust.php";
include "lib/class.sozluk.php";
$sozluk = new sozluk;
?>
<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">bugün</a> <font color="silver" size="1"><? echo $sozluk->bugun();?></font><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
    <?
    $sozluk->baslik_sirala();
    ?>
</ul>
</div>
</div>
<div id="govde">
    <?
    echo '<h2>duyurular & zirve / aktivite </h2>
    <div class="accordion span7 place-left margin10" data-role="accordion" data-closeany="false">
                                    <div class="accordion-frame">
                                        <a class="heading  ribbed-green" href="#" >2. zirve</a>
                                        <div class="content">
                                            <p>elimizde olmayan nedenlerle ertelediğimiz 2.zirveyi 14 Aralık Cumartesi 2013 tarihinde gerçekleştiriyoruz!<br>
                                            <br><strong>wozniak</strong></p>
                                        </div>
                                    </div>
                                    <div class="accordion-frame">
                                        <a class="heading bg-lightBlue" href="#">gönüllü hayalperestler aranıyor</a>
                                        <div class="content">
                                            <p>3-18 yaş arası hayati tehlike taşıyan hasta çocukların hayallerini gerçekleştirmek üzere gönüllü hayalperestler aranıyor<br>
                                            onları çok küçük şeyler mutlu edebiliriz ve bazılarının belki de son istekleri<br>
                                            beykent üniversitesi\'nden bir arkadaşımızın başlattığı bu güzel kampanyaya bizlerde sakarya\'dan destek veriyoruz.<br>
                                            <br><strong>wozniak</strong></p>
                                        </div>
                                    </div>
                                    <div class="accordion-frame">
                                        <a class="heading ribbed-red" href="#">sözlük yazılımı yenilendi</a>
                                        <div class="content">
                                            <p>sözlük yazılımı ve kullanıcı arayüzü yenilendi<br>sizlerle yeniden bir araya gelmek çok güzel! istek ve önerileriniz için yöneticilere mesaj atabilirsiniz<br><br><strong>wozniak</strong></p>
                                        </div>
                                    </div>
                                </div>
  ';
    
    
    ?>
</div>
<script type="text/javascript" src="/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="/js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
    });
</script>
</body>
</html>
