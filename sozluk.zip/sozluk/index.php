<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="description" content="sakarya üniversitesinin internete açılan kapısı, interaktif bilgi kaynağı.yazarlar tarafından oluşturulan bilgi havuzu.">
    <meta name="keywords" content="saü,sakarya üniversitesi,saü tercih,saü sözlük,sakarya üniversitesi taban puanları,sakarya üniversitesi tavsiye,saü tavsiye,saü taban puan,sakarya yurt fiyatları">
    <meta name="author" content="wozniak@sozluksau.com">
    <title>saü sözlük - bir üniversite sözlüğüdür</title>
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/metro-bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    <script src="/js/metro-hint.js"></script>
    <script src="/js/metro-notify.js"></script>
    <script src="/js/jquery.tipsy.js"></script>
    
    </script> 
</head>
<body class="metro">
<?php
include 'sys/config.php';
include "sys/ust.php";
include "lib/class.sozluk.php";
$sozluk = new sozluk;
?>
<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">bugün</a> <font color="silver" size="1">
    <?php echo $sozluk->bugun(); ?></font><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
    <?
    $sozluk->baslik_sirala();
    ?>
</ul>
</div>
</div>
<div id="govde">
    <?
    $sozluk->entry_getir('sozluk-sau',1);
    $sozluk->entry_giris_alani();
    
    ?>
</div>
<script type="text/javascript" src="js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
    });
</script>
</body>
</html>
