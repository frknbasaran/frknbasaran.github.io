<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="/css/reset.css">
    <link rel="stylesheet" href="/css/metro-bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    <script src="/js/metro-accordion.js"></script>
    <title>hoşgeldin evlat - sozluksau.com</title>
</head>
<body class="metro">
<?php
include 'sys/config.php';
include "sys/ust.php";
include "lib/class.sozluk.php";
$sozluk = new sozluk;
?>
<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">bugün</a> <font color="silver" size="1">568</font><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
    <?
    $sozluk->baslik_sirala();
    ?>
</ul>
</div>
</div>
<div id="govde">
    <?
    echo '<h1>hoşgeldin!</h1>
    <h2>ne oldu şimdi?</h2>
    <p>ne olduğunu ben sana söylüyorum iyi dinle, sen seçilmiş birisin evlat. yüzlercesi içinden seni seçtik, sozluksau.com tüm dış mihraklara ajan desteği sağlamayı hedeflemiş gizli ama bunu açıkca dile getirmekten çekinmeyen pislik lanet bi oluşumdur.<br>
    bunların başında israil gizli servisi gelir ama yok hacı ben ibranice öğrenemem yea dersen ingiliz gizli servisi de olabilir.</p>
    <h2>FNG!<a href="../../baslik/fng/">?</a></h2>
    <p>hesabın yöneticilerimiz tarafından onaylanmadan yazdıklarını kimse göremez yazdıklarını herkes görsün hesabım hemen onaylansın istiyorsan ki muhtemelen istiyorsundur, önce girip <a href="../../baslik/ssk">kurallar</a>\'a bi göz atman gerek. daha önce başka sözlüklerde yazmış olabilirsin ya da ilk deneyimin bu oluyor olabilir, hiç fark etmez şu kurallara hafif bir gözat da sonra başın ağrımasın.</p>
    <h2>mail aktivasyon falan yok mu?</h2> 
    <p>yok mail aktivasyonuna falan gerek yok biz gerçek e-posta\'nı gir diye seni kandırdık, sen de söyleme ki yeni gelenler de inanıp yazsınlar hadi bakalım dal içeri ve kendini göster evlat
    <a id="login" style="cursor:pointer">buradan girişe ulaşabilirsin</a>.<br><br><br></p>
    <p>şu güzel şarkı da bizden sana gelsin</p><br>
    <iframe width="420" height="315" src="//www.youtube.com/embed/o9EaKY8lBFw" frameborder="0" allowfullscreen></iframe>
    <br><br><br><strong>saü sözlük pek kıymetli yönetimi</strong><br><br>';
    ?>
</div>
<script type="text/javascript" src="/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="/js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
    });
</script>
</body>
</html>
