<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="/css/reset.css">
    <link rel="stylesheet" href="/css/metro-bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/tipsy.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    <script src="/js/metro-hint.js"></script>
    <script src="/js/metro-notify.js"></script>
    <script src="/js/jquery.tipsy.js"></script>
    <title>şikayet et - saü sözlük</title>
</head>
<body class="metro">
<?php
include 'sys/config.php';
include "sys/ust.php";
include "lib/class.sozluk.php";
$sozluk = new sozluk;
?>
<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">bugün</a> <font color="silver" size="1">568</font><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
    <?
    $sozluk->baslik_sirala();
    ?>
</ul>
</div>
</div>
<div id="govde">
    <?
    $id = intval($_GET['id']);
    $entry = DB::get('SELECT * FROM entry WHERE deleted = 0 and id = "'.$id.'"');
    foreach ($entry as $veri) {
      $baslik = DB::getVar('SELECT goster FROM basliktar WHERE ad = "'.$veri->baslik.'"');
      echo '<h2>bu entryi şikayet et</h2>
      <p>korkma kimliğin bizde saklı ona söylemeyiz</p>
      <input type="text" id="entry_no" style="width:230px" value="#'.$id.' numaralı entry"><br><br>
      <textarea id="sikayet" style="width:230px;height:100px" placeholder="anlat müdür nedir problem"></textarea><br><br>
      <button id="sikayet_et" class="'.$id.'">ağlama melis</button>
      ';
    }
    ?>
</div>
<script type="text/javascript" src="/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="/js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
    });
</script>
</body>
</html>
x