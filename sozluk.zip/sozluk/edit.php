<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="/css/reset.css">
    <link rel="stylesheet" href="/css/metro-bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    <script src="/js/metro-notify.js"></script>
    <title>entry düzenleme - saü sözlük</title>
</head>
<body class="metro">
<?php
include 'sys/config.php';
include "sys/ust.php";
include "lib/class.sozluk.php";
$sozluk = new sozluk;
?>
<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">bugün</a> <font color="silver" size="1">568</font><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
    <?
    $sozluk->baslik_sirala();
    ?>
</ul>
</div>
</div>
<div id="govde">
    <?
    if(isset($_SESSION['user'])){
        $id = intval($_GET['id']);
        $entry = DB::get('SELECT * FROM entry WHERE deleted = 0 and id = "'.$id.'"');
        
        echo '<h2>entry düzenleme</h2>
        <p>#'.$id.' numaralı entryi düzenliyorsun</p>';
        
            foreach ($entry as $veri) {
              
                $authority = $_SESSION['yetki'];
        
                if($authority == 'mod' || $authority == 'admin'){
                  
                  echo '<div class="input-control textarea">
                  <textarea id="entry" placeholder="başlık hakkında dök içini rahatla">'.$sozluk->br2ln($sozluk->convert($veri->metin)).'</textarea>
                  </div>
      
                  <div style="width:80%">
                  <div class="button-set" style="float:left">
                  <button id="bkz">bkz</button>
                  <button id="yildiz">*</button>
                  <button id="link">link</button>
                  <button id="spoiler">spoiler</button>
                  </div>
                  <div class="button-set" style="float:right">
                  <button data-entry="'.$_GET['id'].'" id="edit_entry"><i class="icon-pencil on-left"></i>değiştir</button>
                  </div>
                  </div>';  
                }
                else if($veri->yazar == $_SESSION['user']){
                  
                  echo '<div class="input-control textarea">
                  <textarea id="entry" placeholder="başlık hakkında dök içini rahatla">'.$sozluk->br2ln($sozluk->convert($veri->metin)).'</textarea>
                  </div>  
                  <div style="width:80%">
                  <div class="button-set" style="float:left">
                  <button id="bkz">bkz</button>
                  <button id="yildiz">*</button>
                  <button id="link">link</button> 
                  <button id="spoiler">spoiler</button>
                  </div>
                  <div class="button-set" style="float:right">
                  <button data-entry="'.$_GET['id'].'" id="edit_entry"><i class="icon-pencil on-left"></i>değiştir</button>
                  </div>
                  </div>';
                }
                else{
                
                  echo '<h2>oldu mu şimdi? oldu mu yar?</h2>
                  <p>burayı terk et yoksa güvenlik çağırıcam</p>';
                }
              }  
    }
    else{
        
        echo '<h2> :( olmadı yar</h2>
            <p> bu sayfayı görebilmek için önce sağ üstten giriş yapman lazım</p>';
    }
    
    
    ?>
</div>
<script type="text/javascript" src="/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="/js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
    });
</script>
</body>
</html>
