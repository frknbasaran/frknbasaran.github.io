<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="/css/reset.css">
    <link rel="stylesheet" href="/css/metro-bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    <script src="/js/metro-accordion.js"></script>
    <script src="/js/metro-notify.js"></script>
    <script src="/js/metro-tab-control.js"></script>
    <title>mesajlar - sozluksau.com</title>
</head>
<body class="metro">
<?php
include 'sys/config.php';
include "sys/ust.php";
include "lib/class.sozluk.php";
$sozluk = new sozluk;
?>
<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">bugün</a> <font color="silver" size="1"><? echo $sozluk->bugun();?></font><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
    <?
    $sozluk->baslik_sirala();
    ?>
</ul>
</div>
</div>
<div id="govde">
        <?
        if(isset($_SESSION['user'])){
            if(isset($_GET['to'])){
                $kime=$_GET['to'];
            }else{
                $kime='';
            }
            $okundu = DB::exec('UPDATE user SET msj = 0 WHERE ad = "'.$_SESSION['user'].'"');
            echo '
            <h2>mesajlar</h2>
            <div class="tab-control" data-role="tab-control">
                        <ul class="tabs">
                            <li class="active"><a href="#yeni">mesaj oluştur</a></li>
                            <li><a href="#gelen">gelenler</a></li>
                            <li><a href="#gonderilen">gönderilenler</a></li>
                        </ul>

                        <div class="frames">
                            <div class="frame clearfix" style="width:100%" id="yeni">
                            <h3>yeni bir mesaj gönder</h3>
                            <div class="input-control text" style="width:230px">
                            <input type="text" id="kime" value="'.$kime.'" placeholder="kime"/>
                            </div>
                            <br>
                            <div class="input-control textarea" style="width:500px">
                            <textarea id="mesaj" placeholder="mesaj içeriği"></textarea>
                            </div>
                            <br>
                            <button id="gonder_mesaj" class="primary">Gönder</button>
                            </div>
                            <div class="frame" id="gelen">
                            <h3>gelen mesajlar</h3><div class="accordion span10 place-left margin10" data-role="accordion" data-closeany="false">';
                            $ben = $sozluk->temizle($sozluk->convert($_SESSION['user']));
                            $gelenler = DB::get('SELECT * FROM message WHERE kime = "'.$ben.'" and deleted = "0" and d2 = "0" ORDER BY id DESC');
                            foreach ($gelenler as $mesaj) {
                                $kimden = DB::getVar('SELECT ad FROM user WHERE temiz = "'.$sozluk->convert($mesaj->kimden).'"');
                                echo '<div id="mesaj_baslik '.$mesaj->id.'" class="accordion-frame">
                                        <a class="heading bg-dark fg-white" href="#"><span>'.$sozluk->convert($kimden).'</span><i id="'.$mesaj->id.'" class="icon-remove" style="float:right;margin-left:5px"></i><i id="'.$mesaj->kimden.'" class="icon-cycle" style="float:right;margin-left:5px"></i><span style="float:right">'.$mesaj->tarih.'</span></a>
                                        <div id="'.$mesaj->id.'" class="content">
                                            <p><font size="2">'.$sozluk->convert($mesaj->msj).'</font></p>
                                        </div>
                                    </div>';
                            }
                            echo '</div>
                            </div>
                            <div class="frame" id="gonderilen">
                            <h3>gönderilen mesajlar</h3>
                            <div class="accordion span10 place-left margin10" data-role="accordion" data-closeany="false">';
                            $gelenler = DB::get('SELECT * FROM message WHERE kimden = "'.$ben.'" and deleted = "0" and d1 = "0" ORDER BY id DESC');
                            foreach ($gelenler as $mesaj) {
                                $kime = DB::getVar('SELECT ad FROM user WHERE temiz = "'.$sozluk->convert($mesaj->kime).'"');
                                echo '<div id="mesaj_baslik '.$mesaj->id.'" class="accordion-frame">
                                        <a class="heading bg-dark fg-white" href="#"><span>'.$sozluk->convert($kime).'</span><i id="'.$mesaj->id.'" class="icon-remove" style="float:right;margin-left:5px"></i><span style="float:right">'.$mesaj->tarih.'</span></a>
                                        <div id="'.$mesaj->id.'" class="content">
                                            <p><font size="2">'.$sozluk->convert($mesaj->msj).'</font></p>
                                        </div>
                                    </div>';
                            }
                            echo '</div>
                            </div>
                    </div>


            ';
        }else{
            echo '<h2> :( olmadı yar</h2>
            <p> bu sayfayı görebilmek için önce sağ üstten giriş yapman lazım</p>';
        }
        ?>
</div>

<script type="text/javascript" src="/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="/js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
    });
</script>
</body>
</html>
