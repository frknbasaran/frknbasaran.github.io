<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="/css/reset.css">
    <link rel="stylesheet" href="/css/metro-bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    <script src="/js/metro-accordion.js"></script>
    <script src="/js/metro-notify.js"></script>
    <script src="/js/metro-tab-control.js"></script>
    <title>kullanıcı paneli - sozluksau.com</title>
</head>
<body class="metro">
<?php
include 'sys/config.php';
include "sys/ust.php";
include "lib/class.sozluk.php";
$sozluk = new sozluk;
?>
<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">bugün</a> <font color="silver" size="1"><? echo $sozluk->bugun();?></font><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
    <?
    $sozluk->baslik_sirala();
    ?>
</ul>
</div>
</div>
<div id="govde">
        <?
        if(isset($_SESSION['user'])){
            $row = DB::getRow('SELECT * FROM user WHERE ad = "'.$_SESSION['user'].'"');
            echo '<h2>kullanıcı paneli</h2>
            <div id="profil_resmi">
                <img src="/img/'.$row->img.'" style="float:left;width:90px;height:90px" class="shadow">
                <i style="margin-left:10px;float:left">profil resmini değiştir</i><br>
                <form action="#" method="post" enctype="multipart/form-data">
                <input type="file" style="margin-left:10px;margin-top:10px" name="dosya" />
                <input type="submit" style="margin-top:10px" value="Gönder" />
                </form>
            </div>
            <div style="clear:both"></div>
            <div id="ileti_degistir">
                <h3>kişisel iletini değiştir</h3>
                <div style="width:230px" class="input-control password">
                <input type="text" value="" id="ileti" placeholder="ileti belirle"/>
                </div><br>
                <button id="change_ileti">değiştir</button>
            </div>
            <div id="parola_degistir" style="width:300px;float:left">
                <h3>parola değiştir</h3>
                <div style="width:230px" class="input-control password">
                <input type="password" id="old_pass" value="" placeholder="eski parola"/>
                <button class="btn-reveal"></button>
                </div>
                <div style="width:230px" class="input-control password">
                <input type="password" id="new_pass" value="" placeholder="yeni parola"/>
                <button class="btn-reveal"></button>
                </div>
                <div style="width:230px" class="input-control password">
                <input type="password" value="" id="verify_new_pass" placeholder="yeni parolayı onayla"/>
                <button class="btn-reveal"></button>
                </div>
                <br>
                <button id="change_pass">değiştir</button>
                </div><div id="mail_degistir" style="width:300px;float:left">
                <h3>mail adresini değiştir</h3>
                <div style="width:230px" class="input-control password">
                <input type="text" value="" id="new_mail" placeholder="yeni e-mail"/>
                <button class="btn-reveal"></button>
                </div>
                <div style="width:230px" class="input-control password">
                <input type="password" value="" id="pass" placeholder="parola"/>
                <button class="btn-reveal"></button>
                </div>
                <div style="width:230px" class="input-control password">
                <input type="password" value="" id="pass_verify" placeholder="parolayı onayla"/>
                <button class="btn-reveal"></button>
                </div>
                <br>
                <button id="change_mail">değiştir</button>
                </div>';
        }else{
            echo '<h2> :( olmadı yar</h2>
            <p> bu sayfayı görebilmek için önce sağ üstten giriş yapman lazım</p>';
        }
        ?>
</div>

<script type="text/javascript" src="/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="/js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
    });
</script>
</body>
</html>
<?php

if(isset($_FILES['dosya'])){
   $hata = $_FILES['dosya']['error'];
   if($hata != 0) {
      echo '<script>$.Notify({content:"bişeyler ters gitti"});</script>';
   } else {
      $boyut = $_FILES['dosya']['size'];
      if($boyut > (1024*1024)){
         echo '<script>console.log("'.$isim.$tip.$boyut.'");$.Notify({content:"dosya 1mb den büyük olamaz."});</script>';
      } else {
         $tip = $_FILES['dosya']['type'];
         $isim = $_FILES['dosya']['name'];
         $uzanti = explode('.', $isim);
         $uzanti = $uzanti[count($uzanti)-1];
         if($tip != 'image/jpeg' || $uzanti != 'jpg') {
            echo '<script>console.log("'.$isim.$tip.$boyut.'");$.Notify({content:"sadece jpg dosyaları"});</script>';
         } else {
            $dosya = $_FILES['dosya']['tmp_name'];
            copy($dosya, 'img/' . $_FILES['dosya']['name']);
            $guncelle = DB::exec('UPDATE user SET img = "'.$isim.'" WHERE ad = "'.$_SESSION['user'].'"');
            echo '<script>console.log("'.$isim.$tip.$boyut.'");$.Notify({content:"resim güncellendi"});</script>';   
         }
      }
   }
}

?>