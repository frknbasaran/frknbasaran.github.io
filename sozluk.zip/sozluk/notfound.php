<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="/css/reset.css">
    <link rel="stylesheet" href="/css/metro-bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/tipsy.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    <script src="/js/metro-hint.js"></script>
    <script src="/js/metro-notify.js"></script>
    <script src="/js/jquery.tipsy.js"></script>
    <title>hoop ağır ol muhtar!</title>
    
</head>
<body class="metro">
<?php
include 'sys/config.php';
include "sys/ust.php";
include "lib/class.sozluk.php";
$sozluk = new sozluk;
?>
<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">bugün</a> <font color="silver" size="1">568</font><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
    <?
    $sozluk->baslik_sirala();
    ?>
</ul>
</div>
</div>
<div id="govde">
  <h1>:(<br>sen çok yanlış gelmişsin kardeş</h1>
  <p>bu içerik yok ya da yeri değiştirilmiş kim bilir belki silinmiştir sen geldiğin yoldan dümdüz geri git</p>  
<div style="clear:both"></div>
<div id="footer"><center><a href="">iletişim</a> <a href="">hakkında</a> <a href="">kurallar</a> <a href="">facebook</a> <a href="">twitter</a> <a href="">google+</a></center></div>
</div>

</div>

<script type="text/javascript" src="/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="/js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
      $('.yildizli').tipsy({gravity:'s'});
    });

</script>
</body>
</html>
