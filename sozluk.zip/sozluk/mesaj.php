<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="/css/reset.css">
    <link rel="stylesheet" href="/css/metro-bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    <script src="/js/metro-accordion.js"></script>
    <script src="/js/metro-notify.js"></script>
    <script src="/js/metro-tab-control.js"></script>
    <title>mesajlar - sozluksau.com</title>
</head>
<body class="metro">
<?php
include 'sys/config.php';
include "sys/ust.php";
include "lib/class.mesaj.php";
$mesaj = new Mesaj;
include "lib/class.sozluk.php";
$sozluk = new sozluk;
?>
<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">bugün</a> <font color="silver" size="1"><? echo $sozluk->bugun();?></font><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
    <?
    $sozluk->baslik_sirala();
    ?>
</ul>
</div>
</div>
<script type="text/javascript">
$(document).ready(function(){
    $('.konusma').click(function(){
        var id = $(this).attr('data-id');
        window.location="../mesaj_view.php?konusma="+id;
    });

    $('.yeni').click(function(){
        var alici  = prompt("göndereceğin yazarin nickini yaz");
        var sender = $(this).attr('data-sender'); 
        $.post('http://sozluksau.com/ajax',{process:'konusma_ekle',alici:alici,kimden:sender},function(e){
            window.location="";
        });
    });
});
</script>
<div id="govde">
        <?
        if(isset($_SESSION['user'])){
            echo '<div style="width:70%;" class="mesaj_govde">';
            echo '<div id="mesaj_bar"><h3>konuşmalar</h3><span style="float:right;margin-top:-30px;cursor:pointer" data-sender="'.$_SESSION['user'].'" class="yeni icon-plus-2"> <font face="verdana">yeni konuşma</font></span></div>';
            $id = $mesaj->getIdByName($_SESSION['user']);
            $mesaj->konusmaListele($id);

            echo '</div>';
        }else{
            echo '<h2> :( olmadı yar</h2>
            <p> bu sayfayı görebilmek için önce sağ üstten giriş yapman lazım</p>';
        }
        ?>
</div>

<script type="text/javascript" src="/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="/js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
    });
</script>
</body>
</html>
