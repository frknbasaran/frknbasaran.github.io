<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="/css/reset.css">
    <link rel="stylesheet" href="/css/metro-bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    <script src="/js/metro-accordion.js"></script>
    <title>istatistik - saü sözlük</title>
</head>
<body class="metro">
<?php
include 'sys/config.php';
include "sys/ust.php";
include "lib/class.sozluk.php";
$sozluk = new sozluk;
?>
<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">bugün</a> <font color="silver" size="1"><? echo $sozluk->bugun();?></font><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
    <?
    $sozluk->baslik_sirala();
    ?>
</ul>
</div>
</div>
<div id="govde">
    <?
    $topEntry = DB::getVar('SELECT Count(id) FROM entry');
    $topBaslik = DB::getVar('SELECT Count(id) FROM basliktar');
    $topYazar = DB::getVar('SELECT Count(id) FROM user WHERE yetki != "onaysiz" and yetki != "caylak"');
    $topCaylak = DB::getVar('SELECT Count(id) FROM user WHERE yetki = "caylak"');
    $topAktivasyonsuz = DB::getVar('SELECT Count(id) FROM user WHERE yetki = "onaysiz"');
    echo '<h2>istatistik</h2>
    
    <h3>dünün en beğenilen entryleri</h3>
    ';
    $sozluk->dunun_en_begenilenleri();
    

    echo 

    '<h3>genel bilgiler</h3>
    <table class="table striped">
                        <thead>
                        <tr class="info">
                            <th class="text-left"><b>istatistik</b></th>
                            <th class="text-left"><b>değer</b></th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr><td>toplam entry:</td><td>'.$topEntry.'</td></tr>
                        <tr><td>toplam başlık:</td><td>'.$topBaslik.'</td></tr>
                        <tr><td>toplam yazar:</td><td>'.$topYazar.'</td></tr>
                        <tr><td>toplam çaylak:</td><td>'.$topCaylak.'</td></tr>
                        <tr><td>toplam aktivasyonsuz:</td><td>'.$topAktivasyonsuz.'</td></tr>
                        </tbody>
    </table>
    <h3>en fazla ziyaret edilen başlıklar</h3>
    <table class="table striped">
                        <thead>
                        <tr class="info">
                            <th class="text-left"><b>başlık adı</b></th>
                            <th class="text-left"><b>entry sayısı</b></th>
                        </tr>
                        </thead>
                        <tbody>';
    $basliklar = DB::get('SELECT * FROM basliktar ORDER BY deger DESC LIMIT 10');
    foreach ($basliklar as $baslik) {
        $sayi = DB::getVar('SELECT Count(id) FROM entry WHERE baslik = "'.$baslik->ad.'"');
        echo '<tr><td>'.$sozluk->convert($baslik->goster).'</td><td>'.$sayi.'</td></tr>';
    }

    echo '
                        </tbody>
    </table>
    <h3>ağır işsizler</h3>
    <table class="table striped">
                        <thead>
                        <tr class="info">
                            <th class="text-left"><b>yazar adı</b></th>
                            <th class="text-left"><b>entry sayısı</b></th>
                        </tr>
                        </thead>
                        <tbody>';
    $yazarlar = DB::get('SELECT * FROM user ORDER BY entry_say DESC LIMIT 10');
    foreach ($yazarlar as $veri) {
        echo '<tr><td>'.$sozluk->convert($veri->ad).'</td><td>'.$veri->entry_say.'</td></tr>';
    }

    echo '
                        </tbody>
    </table>
    <h3>en beğenilen yazarlar</h3>
    <table class="table striped">
                        <thead>
                        <tr class="info">
                            <th class="text-left"><b>yazar adı</b></th>
                            <th class="text-left"><b>puanı</b></th>
                        </tr>
                        </thead>
                        <tbody>';
    $yazarlar = DB::get('SELECT * FROM user ORDER BY puan DESC LIMIT 10');
    foreach ($yazarlar as $veri) {
        $puan = $veri->puan;
        $puan = $puan/10;
        echo '<tr><td>'.$sozluk->convert($veri->ad).'</td><td>'.$puan.'</td></tr>';
    }

    echo '
                        </tbody>
    </table>
  ';
    
    
    ?>
</div>
<script type="text/javascript" src="/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="/js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
    });
</script>
</body>
</html>
