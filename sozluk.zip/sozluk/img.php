<!DOCTYPE HTML>
<html>
<head>
<style>
body{
	padding:0;
	margin:0;
}
</style>
</head>
<body>
<?
include "lib/class.sozluk.php"; $sozluk = new sozluk;
include "sys/config.php";
$imgs = DB::get('SELECT * FROM user');
foreach($imgs as $img){
	$ad = $sozluk::convert($img->ad);
	$resim = $sozluk::convert($img->img);
	echo '<img style="margin-top:-5px;width:35px;height:35px;" title="'.$ad.'" src="http://sozluksau.com/img/'.$resim.'">';
}
?>
</body>
</html>