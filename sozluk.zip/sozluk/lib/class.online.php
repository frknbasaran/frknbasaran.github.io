<?
header('content-type:text/html;charset=utf8');
class online{
    
    function kullanici(){
        if(isset($_SESSION['user'])) return $_SESSION['user'];
        else return 'ziyaretci';
    }

    function kontrol($nick,$ip){
        if($nick!='ziyaretci'){
        $denetim = DB::getVar('SELECT Count(id) FROM cevrimici WHERE ad = ?',array($nick));    
        }else{
        $denetim = DB::getVar('SELECT Count(id) FROM cevrimici WHERE ad = ? and ip = ?',array($nick,$ip));
        }
        if($denetim>0){
            $denetim = DB::getVar('SELECT Count(id) FROM cevrimici WHERE ip = ?',array($ip));
        }
        return $denetim;
    }

    function online_ekle($nick,$ip,$url){
        $now = date('Y-m-d H:i:s');
        $ekle = DB::exec('INSERT INTO cevrimici (ad,ip,logdate,ilk,url) VALUES (?,?,?,?,?)',array($nick,$ip,$now,$now,$url));
        if($nick!='ziyaretci') $sil = DB::exec('DELETE FROM online WHERE ip = ? and ad = ?',array($ip,'ziyaretci'));
    }

    function online_kontrol($nick,$ip){
        // kullanıcı bilgilerini tablodan çek
        $data = DB::getRow('SELECT * FROM cevrimici WHERE ad = ? and ip = ?',array($nick,$ip));
        // son hareket verilerini değişkenlere ata
        $ilk_saat = substr($data->ilk,11,2);
        $ilk_dk   = substr($data->ilk,14,2);
        // şimdiki zamanın verilerini değişkenlere ata
        $now = date('Y-m-d H:i:s');
        $smdi_saat = substr($now,11,2);
        $smdi_dk = substr($now,14,2);
        // en son kaç dk önce hareket ettiğini döndür
        $son = mktime($son_saat,$son_dk);
        $smdi = mktime($smdi_saat,$smdi_dk);
        $fark = $smdi-$son;
        return $fark;
    }

    function convert($d){
        $bozuk = array("Ã¶","Ã¼","ÄŸ","Ã§","ÅŸ","Ä±","â€™","<script>","</script>");
        $duzgun = array("ö","ü","ğ","ç","ş","ı","'"," "," ");
        $sonuc = str_replace($bozuk,$duzgun,$d);
        return $sonuc;
    }

    function hareket_kontrol($nick,$ip){
        // kullanıcı bilgilerini tablodan çek
        $data = DB::getRow('SELECT * FROM cevrimici WHERE ad = ? and ip = ?',array($nick,$ip));
        // son hareket verilerini değişkenlere ata
        $son_saat = substr($data->logdate,11,2);
        $son_dk   = substr($data->logdate,14,2);
        // şimdiki zamanın verilerini değişkenlere ata
        $now = date('Y-m-d H:i:s');
        $smdi_saat = substr($now,11,2);
        $smdi_dk = substr($now,14,2);
        // en son kaç dk önce hareket ettiğini döndür
        $son = mktime($son_saat,$son_dk);
        $smdi = mktime($smdi_saat,$smdi_dk);
        $fark = $smdi-$son;
        return $fark;
    }

    function hareket_guncelle($nick,$ip,$url){
        $now = date('Y-m-d H:i:s'); 
        $update = DB::exec('UPDATE cevrimici SET logdate = ?, url = ? WHERE ad = ? and ip = ?',array($now,$url,$nick,$ip));  
    }

    function tablodan_sil($nick,$ip){
        if($nick=='ziyaretci') $sil = DB::exec('DELETE FROM cevrimici WHERE ad = ? and ip = ?',array($nick,$ip));
        else $sil = DB::exec('DELETE FROM cevrimici WHERE ad = ? and ip = ?',array($nick,$ip));
    }

    function sure_string($fark){
        $saat = 0;
        $dk   = 0;
        if($fark>3600){
            $saat = ceil($fark/3600);
            $saat--;
            $fark = $fark % 3600;
            $dk = ceil($fark/60);
            return $saat.' saat '.$dk.' dk';
        }else{
            $dk = $fark / 60;
            return $dk.' dk';
        }
    }

    function genel_kontrol(){
        $all = DB::get('SELECT * FROM cevrimici');
        foreach ($all as $one) {
            $fark = self::hareket_kontrol($one->ad,$one->ip);
            if($fark<0) $fark = $fark + 43200;
            if($fark>1800) self::tablodan_sil($one->ad,$one->ip);
            $toplamFark = self::online_kontrol($one->ad,$one->ip);
        }
    }

    function online_listele(){
        $all = DB::get('SELECT * FROM cevrimici');

        echo '<table class="table hovered bordered">
                        <thead>
                        <tr class="info">
                            <th class="text-left"></th>
                            <th class="text-left"><b>ad</b></th>
                           
                            
                            <th class="text-left">şu an hangi sayfada</th>
                        </tr>
                        </thead>
                        <tbody>
    ';
        foreach ($all as $one) {
            $data = DB::getRow('SELECT * FROM user WHERE ad = ?',array($one->ad));
            $sure = self::sure($one->ad,$one->ip);
            if($one->ad != 'ziyaretci'){
                $yzr++;
                $ad = self::convert($one->ad);
                echo '<tr><td><img class="shadow" style="float:left;width:20px;height:20px" src="http://sozluksau.com/img/'.$data->img.'"></td><td><a href="../../yazar/'.$data->temiz.'/">'.$ad.'</a></td><td><a href="../..'.$one->url.'">'.substr($one->url,0,60).'..</a></td></tr>';    
            }else{
                $ziyaretci++;
            }
        }
        echo '</tbody></table><br><strong>'.$yzr. '</strong> yazar ve <strong>'.$ziyaretci.'</strong> ziyaretci';
    }
  function sure($nick,$ip){
        // kullanıcı verilerini çek
        $data = DB::getRow('SELECT * FROM cevrimici WHERE ip = ? and ad = ?', array($ip,$nick));
        // degiskenlere ata
        $ilk_saat = substr($data->ilk,11,2);
        $ilk_dk   = substr($data->ilk,14,2);
        $now = date('Y-m-d H:i:s');
        $smdi_saat = substr($now,11,2);
        $smdi_dk   = substr($now,14,2);
        $ilk_gn    = substr($data->ilk,8,2);
        $smdi_gn   = substr($now,8,2);
        $ay = substr($now,5,2);
        $yil = substr($now,0,4);
        // ne kadar süredir online olduğunu hesapla
        $ilk  = mktime($ilk_saat,$ilk_dk,0,$ay,$ilk_gn,$yil);
        $smdi = mktime($smdi_saat,$smdi_dk,0,$ay,$ilk_gn,$yil);
        $gun_farki = $smdi_gn - $ilk_gn;
        $fark = $smdi-$ilk;
        // string fonksiyonuna gönder, ardından gelen değeri döndür
        return self::sure_string($fark);
    }

    function main(){
        // değişkenleri ata
        $nick = self::kullanici();    
        $ip   = $_SERVER['REMOTE_ADDR'];
        $url  = $_SERVER['REQUEST_URI'];
        // bu kullanıcı tabloda var mı kontrol et
        $kontrol = self::kontrol($nick,$ip);
        
        if($kontrol==0) self::online_ekle($nick,$ip,$url);
        // son hareket zamanını $fark degiskenine ata
        $fark = self::hareket_kontrol($nick,$ip);
        if($fark>1800) self::tablodan_sil($nick,$ip);
        else self::hareket_guncelle($nick,$ip,$url);
        // tablodaki her kullanıcıyı kontrol et
        self::genel_kontrol();
    }
}
?>