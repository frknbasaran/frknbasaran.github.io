<?
class chat{
	
}
?>