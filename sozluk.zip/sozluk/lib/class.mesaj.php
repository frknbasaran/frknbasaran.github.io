<?
class Mesaj{
	
	public function convert($d){
    	$bozuk = array("Ã‡","Ã¶","Ã¼","ÄŸ","Ã§","ÅŸ","Ä±","â€™","<script>","</script>");
    	$duzgun = array("ç","ö","ü","ğ","ç","ş","ı","'"," "," ");
    	$sonuc = str_replace($bozuk,$duzgun,$d);
    	return $sonuc;
	}

	public function tarihFiltre($date){
		$now = date('Y-m-d h:i:s');
		
		$smdi_yil = intval(substr($now,0,4));
		$eski_yil = intval(substr($date,0,4));
		$smdi_ay  = intval(substr($now,5,2));
		$eski_ay  = intval(substr($date,5,2));
		$smdi_gun = intval(substr($now,8,2));
		$eski_gun = intval(substr($date,8,2));
		$smdi_saat = intval(substr($now,11,2));
		$eski_saat = intval(substr($date,11,2));
		$smdi_dk  = intval(substr($now,14,2));
		$eski_dk  = intval(substr($date,14,2));
		$smdi_sn  = intval(substr($now,17,2));
		$eski_sn  = intval(substr($date,17,2));

		if($smdi_yil-$eski_yil>0){
			return $smdi_yil-$eski_yil.' yıl önce';
		}else if($smdi_ay-$eski_ay>0){
			return $smdi_ay-$eski_ay.' ay önce';
		}else if($smdi_gun-$eski_gun>0){
			return $smdi_gun-$eski_gun.' gün önce';
		}else if($smdi_saat-$eski_saat>0){
			return $smdi_saat-$eski_saat.' saat önce';
		}else if($smdi_dk-$eski_dk>0){
			return $smdi_dk-$eski_dk.' dakika önce';
		}else if($smdi_sn-$eski_sn>0){
			return $smdi_sn-$eski_sn.' saniye önce';
		}

	}

	public function parseKonusma($user,$u1,$u2,$tarih,$id){
		if($u1==$user){
			$user = db::getRow('SELECT * FROM user WHERE id = ?',array($u2));
			$online = DB::getVar('SELECT * FROM cevrimici WHERE ad = ?',array($user->ad));
			$conv_data = db::getRow('SELECT * FROM konusma WHERE id = ?',array($id));
			if($conv_data->d1!=1){
				if($online>0){
					if($conv_data->r2!=0){
						echo '<div data-id="'.$id.'" class="konusma"><img style="border:2px solid #5FB404;width:40px;height:40px;margin:10px" src="http://sozluksau.com/img/'.$user->img.'"><span class="konusma_ad"><strong>'.self::convert($user->ad).'</strong> yeni mesaj var!</span><span id="'.$id.'" class="sil_konusma icon-remove"></span><span class="konusma_tarih">'.self::tarihFiltre($tarih).'</span></div>';		
					}else{
						echo '<div data-id="'.$id.'" class="konusma"><img style="border:2px solid #5FB404;width:40px;height:40px;margin:10px" src="http://sozluksau.com/img/'.$user->img.'"><span class="konusma_ad"><strong>'.self::convert($user->ad).'</strong></span><span id="'.$id.'" class="sil_konusma icon-remove"></span><span class="konusma_tarih">'.self::tarihFiltre($tarih).'</span></div>';		
					}
				}else{
					if($conv_data->r1!=0){
						echo '<div data-id="'.$id.'" class="konusma"><img style="border:2px solid silver;width:40px;height:40px;margin:10px" src="http://sozluksau.com/img/'.$user->img.'"><span class="konusma_ad"><strong>'.self::convert($user->ad).'</strong> yeni mesaj var!</span><span id="'.$id.'" class="sil_konusma icon-remove"></span><span class="konusma_tarih">'.self::tarihFiltre($tarih).'</span></div>';
					}else{
						echo '<div data-id="'.$id.'" class="konusma"><img style="border:2px solid silver;width:40px;height:40px;margin:10px" src="http://sozluksau.com/img/'.$user->img.'"><span class="konusma_ad"><strong>'.self::convert($user->ad).'</strong></span><span id="'.$id.'" class="sil_konusma icon-remove"></span><span class="konusma_tarih">'.self::tarihFiltre($tarih).'</span></div>';
					}					
				}
			}
		}else{
			$user = db::getRow('SELECT * FROM user WHERE id = ?',array($u1));
			$online = DB::getVar('SELECT * FROM cevrimici WHERE ad = ?',array($user->ad));
			$conv_data = db::getRow('SELECT * FROM konusma WHERE id = ?',array($id));
			if($conv_data->d2!=1){
				if($online>0){
					echo '<div data-id="'.$id.'" class="konusma"><img style="border:2px solid #5FB404;width:40px;height:40px;margin:10px" src="http://sozluksau.com/img/'.$user->img.'"><span class="konusma_ad"><strong>'.self::convert($user->ad).'</strong></span><span id="'.$id.'" class="sil_konusma icon-remove"></span><span class="konusma_tarih">'.self::tarihFiltre($tarih).'</span></div>';	
				}else{
					echo '<div data-id="'.$id.'" class="konusma"><img style="border:2px solid silver;width:40px;height:40px;margin:10px" src="http://sozluksau.com/img/'.$user->img.'"><span class="konusma_ad"><strong>'.self::convert($user->ad).'</strong></span><span id="'.$id.'"  class="sil_konusma icon-remove"></span><span class="konusma_tarih">'.self::tarihFiltre($tarih).'</span></div>';
				}
			}
		}
	}

	public function okundu($id){
		$update = db::exec('UPDATE konusma SET r1 = 0,r2 = 0 WHERE id = ?',array($id));
	}

	public function konusmaListele($user){
		$konusmalar1 = DB::get('SELECT id FROM konusma WHERE u1 = ? ORDER BY tarih DESC',array($user));
		$konusmArray1 = array();
		$sayac=0;
		
		foreach ($konusmalar1 as $konusma) {
			$konusmArray1[$sayac] = $konusma->id;
			$sayac++;
		}
		
		$konusmalar2 = DB::get('SELECT id FROM konusma WHERE u2 = ? ORDER BY tarih DESC',array($user));
		$konusmArray2 = array();
		foreach ($konusmalar2 as $konusma) {
			$konusmArray2[$sayac] = $konusma->id;
			$sayac++;
		}

		foreach ($konusmArray1 as $konusma) {
			$konusmaData = DB::getRow('SELECT * FROM konusma WHERE id = ?',array($konusma));
			self::parseKonusma($user,$konusmaData->u1,$konusmaData->u2,$konusmaData->tarih,$konusmaData->id);
		}
		foreach ($konusmArray2 as $konusma) {
			$konusmaData = DB::getRow('SELECT * FROM konusma WHERE id = ?',array($konusma));
			self::parseKonusma($user,$konusmaData->u1,$konusmaData->u2,$konusmaData->tarih,$konusmaData->id);
		}
	}

	public function returnOther($konusma,$me){
		$konusmaData = db::getRow('SELECT * FROM konusma WHERE id = ?',array($konusma));
		if($konusmaData->u1!=$me) return $konusmaData->u1;
		else return $konusmaData->u2;
	}

	public function guvenlikKontrol($konusma,$user){
		$konusmaData = db::getRow('SELECT * FROM konusma WHERE id = ?',array($konusma));
		if($konusmaData->u1==$user or $konusmaData->u2==$user){
			return true;
		}else{
			return false;
		}
	}

	public function mesajSirala($id,$user){
		$mesajlar = db::get('SELECT * FROM mesaj WHERE konusma = ? ORDER BY id ASC',array($id));
		foreach ($mesajlar as $mesaj) {
			if($mesaj->gonderen==$user and $mesaj->d1==0){
				echo '<div class="sag_mesaj">'.$mesaj->mesaj.'</div><div style="clear:both"></div>';
			}else if($mesaj->alici==$user and $mesaj->d2==0){
				echo '<div class="sol_mesaj">'.$mesaj->mesaj.'</div><div style="clear:both"></div>';
			}
		}
	}

	public function konusmaKontrol($user,$to){
		$userSorgu = DB::getVar('SELECT Count(id) FROM konusma WHERE u1 = ? and u2 = ?',array($user,$to));
		$otherSorgu = DB::getVar('SELECT Count(id) FROM konusma WHERE u1 = ? and u2 = ?',array($to,$user));
		if($userSorgu<1 and $otherSorgu<1){
			return DB::insert('INSERT INTO konusma (u1,u2) VALUES (?,?)',array($user,$to));
		}else if($userSorgu>0){
			$data = db::getRow('SELECT * FROM konusma WHERE u1 = ? and u2 = ?',array($user,$to));
			if($data->d1!=0) $guncelle = db::query('UPDATE konusma SET d1 = 0 WHERE u1 = ? and u2 = ?',array($user,$to));
			return db::getVar('SELECT id FROM konusma WHERE u1 = ? and u2 = ?',array($user,$to));
		}else if($otherSorgu>0){
			$data = db::getRow('SELECT * FROM konusma WHERE u1 = ? and u2 = ?',array($to,$user));
			if($data->d1!=0) $guncelle = db::query('UPDATE konusma SET d1 = 0 WHERE u1 = ? and u2 = ?',array($to,$user));
			return db::getVar('SELECT id FROM konusma WHERE u1 = ? and u2 = ?',array($to,$user));
		}
	}

	public function yeniKonusma($user,$to){
		$konusmaId = self::konusmaKontrol($user,$to);
		echo $konusmaId;
	}

	public function getIdByName($name){
		return db::getVar('SELECT id FROM user WHERE ad = ?',array($name));
	}

	public function returnReceiverId($konusma,$me){
		$conv_data = db::getRow('SELECT * FROM konusma WHERE id = ?',array($konusma));
		if($conv_data->u1==$me) return $conv_data->u2;
		else return $conv_data->u1;
	}

	
	public function yeni_msj($konusma,$sender,$receiver,$msj){
		$date = date('d-m-Y H:i:s');
		$gonder = db::insert('INSERT INTO mesaj (gonderen,alici,konusma,tarih,mesaj) VALUES (?,?,?,?,?)', array($sender,$receiver,$konusma,$date,$msj));
	}
	
}
?>