<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="http://faviconist.com/icons/c323188dcfe9646a44c28c379958b430/favicon.ico" />
    <link rel="stylesheet" href="/css/reset.css">
    <link rel="stylesheet" href="/css/metro-bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <script src="/js/jquery/jquery.min.js"></script>
    <script src="/js/jquery/jquery.widget.min.js"></script>
    <script src="/js/metro-dropdown.js"></script>
    <script src="/js/metro-accordion.js"></script>
    
    </script> 
    <title>hakkında - sozluksau.com</title>
</head>
<body class="metro">
<?php
include 'sys/config.php';
include "sys/ust.php";
include "lib/class.sozluk.php";
$sozluk = new sozluk;
?>
<div id="basliklar">
<span id="bugun"><a class="bugun" style="color:black;cursor:pointer;">bugün</a> <font color="silver" size="1"><? echo $sozluk->bugun();?></font><br></span>
<div id="left-side">
<ul id="baslik_listesi" style="list-style:none">
    <?
    $sozluk->baslik_sirala();
    ?>
</ul>
</div>
</div>
<div id="govde">
    <?
    echo '<center>
    <h2>saü sözlük - sozluksau.com</h2>
    <strong>programlama / arayüz tasarımı</strong><br><br>
    <a href="../../yazar/wozniak/">wozniak</a><br>
    <br>
    <strong>içerik yönetimi & moderasyon</strong><br><br>
    <a href="../../yazar/tom-tucker/">tom tucker</a><br>
    <a href="../../yazar/tasidelenazim/">tasidelenazim</a><br>
    <a href="../../yazar/paul-c/">paul c</a><br>
    <a href="../../yazar/mia/">mia</a><br>
    <br>
    

    <br>
    <strong>teşekkürler</strong><br><br>
    <a href="../../yazar/guguluk/">guguluk</a><br><br>
    <strong>çok çok teşekkürler</strong><br><br>
    <a href="../../yazar/noktakomm/">noktakomm</a><br>
    <br>
    şubat 13\'
    </center>


    ';
    ?>
</div>
<script type="text/javascript" src="/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="/js/system.js"></script>
   <script type="text/javascript">
    $(function(){
      $('#left-side').slimScroll({
          alwaysVisible: true,
          railVisible: true,
          disableFadeOut: true
      });
    });
</script>
</body>
</html>
