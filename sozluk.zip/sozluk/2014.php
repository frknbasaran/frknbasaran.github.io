<?
header('content-type:text/html;charset=utf8');
echo 'olm işsiz misin ya<br>şimdi git seneye gel<br>öperler';
?>