// FurkanBASARAN.js
// web developer, computer engineer

// PERSONAL INFORMATIONS

var nameSurname = "Furkan BAŞARAN"; 
var email       = "frknbasaran@gmail.com";
var webPage     = "furkanbasaran.com";

var socialAccounts = {
    "github"    :   "github.com/frknbasaran",
    "twitter"   :   "twitter.com/frknbasaran",
    "facebook"  :   "facebook.com/frknbasaran",
    "instagram" :   "instagram.com/frknbasaran"
}

var careerTarget = "Make a better softwares for everyone on the world";

// TECHNICAL SKILLS

var techSkills = [
    {
        "webDevelopment" : 
        [
            "php","nodeJs","java","javaServerPages","spring","maven","oracle11gR2","sql","plSql","toad","hibernate","mySql",
            "mongoDB","mongoose","javascript","jQuery","underscore","ejs","express","jade","angularJs","firebase","backboneJs","socket.io","passportJs"
        ],
        "webDesign"      : 
        [
            "html5","css3","web ui frameworks","javascript"
        ],
        "softwareArchitectures" : 
        [
    "objectOrientedProgramming","relationalDatabaseManagementSystems","UML","noSqlDatabaseSystems","softwareDesignPatterns","restfulWebServices"
        ],
        "desktopProgramming" : 
        [
            "vb.net","c#","c/c++","java","swing"
        ]
    }
];

// WORKING EXPERIENCES

var workExperiences = {
    "toyotaSummerIntern" : {
        "company"       :   "Toyota Motor Europe",
        "workingTime"   :   "2 Months",
        "position"      :   "Software Development Intern",
        "workingPeriod" :   "2014-06 / 2014-08"
    },
    "toyotaHalfTimeSoftwareEngineer" : {
        "company"       :   "Toyota Motor Europe",
        "workingTime"   :   "Still Working",
        "position"      :   "Java / NodeJS Developer",
        "workingPeriod" :   "2014-10 / .."
    }
};

// PERSONAL PROJECTS

var projects = {
    "campusca"      :   {
        "platform"  :   "web",
        "techs"     :   "nodeJS, express, socket.io, mongoDB, mongoose, ejs",
        "desc"      :   "social network for university students, this project winner Girisim Atölyesi 2014, and supported by sakarya teknokent",
        "sourceAddr":   "this repository private"
    },
    "racerSticksIO" : {
        "platform"  :   "web",
        "techs"     :   "nodeJS, socket.io, jQuery",
        "desc"      :   "Browser based real time multi-player stick racer game",
        "sourceAddr":   "http://github.com/frknbasaran/racersticks-io"
    },
    "sausozlukNodeJS" : {
        "platform"  :   "web",
        "techs"     :   "nodeJS, express, mongoDB, mongoose, backboneJS, flatUiCssFramework",
        "desc"      :   "Anonymously social-wiki like eksisozluk.com for Sakarya University students, featured backbone app below offical repository https://github.com/jashkenas/backbone/wiki/Projects-and-Companies-using-Backbone#sa%C3%BC-s%C3%B6zl%C3%BCk",
        "sourceAddr":   "this repository private"
    },
    "sausozlukPHP"  :   {
        "platform"  :   "web",
        "techs"     :   "php, mysql, semanticUiCssFramework, jQuery",
        "desc"      :   "Anonymously social-wiki like eksisozluk.com for Sakarya University students",
        "sourceAddr":   "http://github.com/frknbasaran/sau-sozluk-php"
    },
    "tweetzy"       :   {
        "platform"  :   "web",
        "techs"     :   "nodeJS, express, passportJS, socket.io, twitterRestAPI, twitterStreamingAPI, googleMapsAPI",
        "desc"      :   "location based tweet finding and showing on maps",
        "sourceAddr":   "http://github.com/frknbasaran/tweetzy"
    },
    "fuckRegExp"    :   {
        "platform"  :   "web",
        "techs"     :   "php",
        "desc"      :   "simple string parser class on php",
        "sourceAddr":   "http://github.com/frknbasaran/fuckRegExp"
    },
    "toyotaJapaneseRestaurantManagementSystem"  :   {
        "platform"  :   "web",
        "techs"     :   "nodeJS, express, mongoDb, mongoose , ejs, metroUiCSSFramework, jQuery",
        "desc"      :   "restaurant management system developed for toyota internt contest 2014, winner project",
        "sourceAddr":   "http://github.com/frknbasaran/ToyotaJapnRest"
    }
}

